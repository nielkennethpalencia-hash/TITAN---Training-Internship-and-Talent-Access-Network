<?php
// ---- Edit these settings ----
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'internhub',   // created automatically on first run
        'user' => 'root',        // XAMPP default
        'pass' => '',            // XAMPP default is empty
    ],
    // First admin (head teacher) - created automatically if no admin exists
    'admin' => [
        'name'     => 'Head Teacher',
        'email'    => 'admin@school.edu',
        'password' => 'Admin@12345',
    ],
    // Email for "accepted" notifications. Leave host empty to log emails to storage/mail.log instead.
    'smtp' => [
        'host'      => '',                      // e.g. smtp.gmail.com
        'port'      => 587,                     // 587 (STARTTLS) or 465 (SSL)
        'user'      => '',                      // e.g. youraccount@gmail.com
        'pass'      => '',                      // Gmail App password
        'from'      => '',                      // usually same as user
        'from_name' => 'InternHub',
    ],
    'session_minutes' => 20,
];
