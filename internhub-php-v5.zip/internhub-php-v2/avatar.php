<?php
// Serves a profile picture / company logo to any logged-in user; draws a coloured initial when none is uploaded.
require __DIR__ . '/includes/bootstrap.php';
if (!user()) { http_response_code(403); exit; }
$uid = (int)($_GET['uid'] ?? 0);
$q = db()->prepare('SELECT avatar_path, name FROM users WHERE id=?');
$q->execute([$uid]);
$u = $q->fetch();
if (!$u) { http_response_code(404); exit; }
session_write_close();
$file = $u['avatar_path'] ? avatar_dir() . '/' . basename($u['avatar_path']) : '';
if ($file && is_file($file)) {
    $types = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    $etag = '"' . md5($u['avatar_path']) . '"';
    header('ETag: ' . $etag);
    header('Cache-Control: private, max-age=0, must-revalidate');
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }
    header('Content-Type: ' . ($types[strtolower(pathinfo($file, PATHINFO_EXTENSION))] ?? 'application/octet-stream'));
    header('X-Content-Type-Options: nosniff');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
$initial = mb_strtoupper(mb_substr(trim((string)($u['name'] ?: ($_GET['n'] ?? '?'))), 0, 1)) ?: '?';
$colors = ['#0d9488', '#2563eb', '#7c3aed', '#db2777', '#d97706', '#16a34a', '#0891b2', '#dc2626'];
$bg = $colors[$uid % count($colors)];
header('Content-Type: image/svg+xml');
header('Cache-Control: private, max-age=3600');
echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="' . $bg . '"/>'
   . '<text x="50" y="50" dy=".35em" text-anchor="middle" font-family="Segoe UI,Arial,sans-serif" font-size="46" font-weight="700" fill="#fff">' . htmlspecialchars($initial, ENT_XML1) . '</text></svg>';
