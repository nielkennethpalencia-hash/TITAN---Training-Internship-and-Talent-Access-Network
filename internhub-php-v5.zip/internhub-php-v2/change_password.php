<?php
require __DIR__ . '/includes/bootstrap.php';
if (!user()) redirect('index.php');

if (!$_SESSION['must_change']) redirect(home_for($_SESSION['role']) === 'admin/index.php' ? 'admin/profile.php' : ($_SESSION['role'] . '/profile.php'));  // normal password changes live in each Profile page

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    handle_password_change();
    if (empty($_SESSION['must_change'])) redirect(home_for($_SESSION['role']));
    redirect('change_password.php');
}
$first = true;
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Password - InternHub</title><link rel="stylesheet" href="<?= e(url('assets/style.css')) ?>"></head><body>
<div class="auth-wrap single">
  <form class="auth-card" method="post">
    <h2><?= $first ? 'Set your own password' : 'Change password' ?></h2>
    <?php if ($first): ?><p class="muted">Your account was created by the head teacher. Please replace the temporary password.</p><?php endif; ?>
    <?php if (!empty($_SESSION['flash'])) { [$t, $m] = $_SESSION['flash']; unset($_SESSION['flash']); echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>'; } ?>
    <?= csrf_field() ?>
    <label class="field"><span><?= $first ? 'Temporary password' : 'Current password' ?></span><input type="password" name="current" required></label>
    <label class="field"><span>New password</span><input type="password" name="new" minlength="6" required></label>
    <label class="field"><span>Confirm new password</span><input type="password" name="confirm" minlength="6" required></label>
    <button class="btn primary block">Save password</button>
    <p class="center"><a href="logout.php">Log out</a></p>
  </form>
</div></body></html>
