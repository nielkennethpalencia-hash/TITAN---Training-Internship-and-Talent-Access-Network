<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('student');
$me = current_student();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'cancel') {
        $d = db()->prepare('DELETE FROM recommendations WHERE id=? AND student_id=?');
        $d->execute([(int)post('id'), $me['id']]);
        flash($d->rowCount() ? 'ok' : 'err', $d->rowCount() ? 'Application cancelled. You can apply again anytime.' : 'Application not found');
    }
    $back = ['index' => 'student/index.php', 'requests' => 'student/requests.php'][post('back')] ?? 'student/requests.php';
    if (post('back') === 'company') $back = 'student/company.php?id=' . (int)post('company_id');
    redirect($back);
}
$s = db()->prepare('SELECT r.*, c.user_id AS cuid, c.company_name, c.industry, c.address FROM recommendations r JOIN companies c ON c.id=r.company_id WHERE r.student_id=? ORDER BY r.created_at DESC');
$s->execute([$me['id']]);
$recs = $s->fetchAll();
page_start('My requests', student_tabs(), 'requests.php');
?>
<div class="page-head"><div><h1>My requests</h1><p class="muted">Your applications and recommendations from your head teacher</p></div></div>
<div class="card">
<?php if (!$recs): ?><div class="empty">No applications yet.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Company</th><th>Sent by</th><th>Match</th><th>Status</th><th>Interview schedule</th><th></th></tr></thead><tbody>
<?php foreach ($recs as $r): ?>
<tr><td><?= who_html((int)$r['cuid'], $r['company_name'], e($r['industry']), true, 38, modal_company((int)$r['cuid'])) ?></td>
<td><?= $r['recommended_by'] === 'admin' ? 'Head teacher' : 'You' ?></td><td><?= score_html($r['match_score']) ?></td><td><?= badge_html($r['status']) ?></td><td><?= interview_html($r) ?></td>
<td class="actions"><?= cancel_form($r, 'requests') ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php page_end();
