<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('student');
$me = current_student();
$q = db()->prepare("SELECT r.*, c.user_id AS cuid, c.company_name, c.address, c.phone FROM recommendations r JOIN companies c ON c.id=r.company_id
    WHERE r.student_id=? AND r.status='accepted' ORDER BY r.interview_at IS NULL, r.interview_at ASC");
$q->execute([$me['id']]);
$upcoming = $past = $tba = [];
foreach ($q->fetchAll() as $r) {
    if (!$r['interview_at']) $tba[] = $r;
    elseif (strtotime($r['interview_at']) >= time()) $upcoming[] = $r;
    else $past[] = $r;
}
$past = array_reverse($past);
$list = function (array $rows, string $empty) {
    if (!$rows) { echo '<div class="empty">' . e($empty) . '</div>'; return; }
    echo '<div class="table-wrap"><table><thead><tr><th>Company</th><th>Interview schedule</th><th>Contact</th></tr></thead><tbody>';
    foreach ($rows as $r) {
        echo '<tr><td>' . who_html((int)$r['cuid'], $r['company_name'], '', true, 38, modal_company((int)$r['cuid'])) . '</td><td>' . interview_html($r)
           . '</td><td class="muted sm">' . e($r['phone'] ?: '-') . '</td></tr>';
    }
    echo '</tbody></table></div>';
};
page_start('Schedule', student_tabs(), 'schedule.php');
?>
<div class="page-head"><div><h1>My schedule</h1><p class="muted">Your face-to-face interviews with companies that accepted you</p></div></div>
<div class="card"><div class="card-head"><h3>Upcoming (<?= count($upcoming) ?>)</h3></div><?php $list($upcoming, 'No upcoming interviews.'); ?></div>
<?php if ($tba): ?><div class="card"><div class="card-head"><h3>Waiting for a schedule (<?= count($tba) ?>)</h3></div><?php $list($tba, ''); ?></div><?php endif; ?>
<?php if ($past): ?><div class="card"><div class="card-head"><h3>Past (<?= count($past) ?>)</h3></div><?php $list($past, ''); ?></div><?php endif; ?>
<?php page_end();
