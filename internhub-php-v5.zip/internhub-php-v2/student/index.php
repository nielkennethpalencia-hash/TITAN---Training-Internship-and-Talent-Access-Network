<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('student');
$pdo = db();
$me = current_student();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $c = $pdo->prepare('SELECT * FROM companies WHERE id=?'); $c->execute([(int)post('company_id')]); $co = $c->fetch();
        if (!$co) throw new Exception('Company not found');
        $pdo->prepare("INSERT INTO recommendations(student_id,company_id,recommended_by,match_score) VALUES(?,?,'student',?)")
            ->execute([$me['id'], $co['id'], match_score($me['skills'], $co['required_skills'])]);
        flash('ok', 'Application sent to ' . $co['company_name']);
    } catch (PDOException $ex) {
        flash('err', $ex->getCode() == 23000 ? 'You already applied to this company' : $ex->getMessage());
    } catch (Throwable $ex) { flash('err', $ex->getMessage()); }
    redirect('student/index.php');
}

$status = [];
$s = $pdo->prepare('SELECT id, company_id, status FROM recommendations WHERE student_id=?'); $s->execute([$me['id']]);
foreach ($s->fetchAll() as $r) $status[$r['company_id']] = $r;
$companies = $pdo->query("SELECT c.*, u.email FROM companies c JOIN users u ON u.id=c.user_id WHERE u.status='approved'")->fetchAll();
foreach ($companies as &$c) $c['score'] = match_score($me['skills'], $c['required_skills']);
unset($c);
usort($companies, fn($a, $b) => $b['score'] <=> $a['score']);
$accepted = $pdo->prepare("SELECT c.company_name, r.interview_at, r.interview_place, r.interview_notes, r.status FROM recommendations r JOIN companies c ON c.id=r.company_id WHERE r.student_id=? AND r.status='accepted' LIMIT 1");
$accepted->execute([$me['id']]); $acc = $accepted->fetch();

page_start('Companies', student_tabs(), 'index.php');
?>
<div class="page-head"><div><h1>My internship</h1><p class="muted">Browse companies, view their details and apply</p></div></div>
<?php if ($acc): ?><div class="flash ok">🎉 You've been accepted by <b><?= e($acc['company_name']) ?></b>.
  <div style="margin-top:8px"><strong>Face-to-face interview:</strong> <?= interview_html($acc) ?></div></div><?php endif; ?>
<div class="cards">
<?php if (!$companies): ?><div class="empty">No companies available yet.</div><?php endif; ?>
<?php foreach ($companies as $c):
    $rec = $status[$c['id']] ?? null;
    $applyForm = '<form method="post" class="inline">' . csrf_field() . '<input type="hidden" name="company_id" value="' . (int)$c['id'] . '"><button class="btn primary sm">Apply</button></form>';
    $act = $rec ? '<div class="btn-row">' . badge_html($rec['status']) . cancel_form($rec, 'index') . '</div>' : $applyForm;
    register_modal('m' . (int)$c['id'], company_modal_inner($c, '<h4>Your match</h4>' . score_html($c['score']),
        '<span class="muted sm">' . ($rec ? 'You already applied to this company.' : 'Ready to join? Send your application.') . '</span>' . $act)); ?>
  <div class="card company"<?= modal_attrs('m' . (int)$c['id']) ?>>
    <div class="card-head"><?= who_html((int)$c['user_id'], $c['company_name'], e($c['industry']) . ($c['address'] ? ' · ' . e($c['address']) : ''), true, 48) ?><?= score_html($c['score']) ?></div>
    <div class="muted sm">Skills needed</div><?= skills_html($c['required_skills']) ?>
    <div class="card-foot"><span class="muted sm">Click for full details · <?= (int)$c['slots'] ?> slot(s)</span><?= $act ?></div>
  </div>
<?php endforeach; ?>
</div>
<?php page_end();
