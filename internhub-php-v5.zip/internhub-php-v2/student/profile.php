<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('student');
$me = current_student();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = post('action');
    if ($act === 'password') handle_password_change();
    elseif ($act === 'remove_avatar') { try { save_avatar((int)$_SESSION['uid'], [], true); flash('ok', 'Profile picture removed'); } catch (Throwable $ex) { flash('err', $ex->getMessage()); } }
    elseif ($act === 'remove_resume') { remove_resume((int)$me['id']); flash('ok', 'Resume removed'); }
    else {
        try {
            db()->prepare('UPDATE students SET student_id=?, course=?, year_level=?, phone=?, about=? WHERE id=?')
                ->execute([post('student_id'), post('course'), post('year_level'), post('phone'), post('about'), $me['id']]);
            if (post('name') !== '') { db()->prepare('UPDATE users SET name=? WHERE id=?')->execute([post('name'), $_SESSION['uid']]); $_SESSION['name'] = post('name'); }
            save_resume((int)$me['id'], $_FILES['resume'] ?? []);
            save_avatar((int)$_SESSION['uid'], $_FILES['avatar'] ?? []);
            flash('ok', 'Profile saved');
        } catch (Throwable $ex) { flash('err', $ex->getMessage()); }
    }
    redirect('student/profile.php');
}
$me['student_pk'] = $me['id'];
page_start('My profile', student_tabs(), 'profile.php');
?>
<div class="page-head"><div><h1>My profile</h1><p class="muted">Keep your details and resume up to date</p></div></div>
<form class="card" method="post" enctype="multipart/form-data"><?= csrf_field() ?>
  <div class="grid2">
    <?= avatar_field_html((int)$_SESSION['uid'], $me['name'], 'Profile picture', false) ?>
    <label class="field"><span>Full name</span><input name="name" value="<?= e($me['name']) ?>"></label>
    <label class="field"><span>Email</span><input value="<?= e($me['email']) ?>" disabled></label>
    <label class="field"><span>Student ID</span><input name="student_id" value="<?= e($me['student_id']) ?>"></label>
    <label class="field"><span>Phone</span><input name="phone" value="<?= e($me['phone']) ?>"></label>
    <label class="field"><span>Course</span><?= course_select($me['course']) ?></label>
    <label class="field"><span>Year level</span><?= year_select($me['year_level']) ?></label>
    <div class="field full"><span>Resume (PDF, DOC or DOCX, max 5 MB)</span>
      <?php if ($me['resume_path']): ?><div class="btn-row" style="margin:6px 0 8px">Current: <strong><?= e($me['resume_name']) ?></strong> <?= resume_link($me) ?>
        <button class="btn sm danger" name="action" value="remove_resume" formnovalidate onclick="return confirm('Remove your resume?')">Remove resume</button></div><?php endif; ?>
      <input type="file" name="resume" accept=".pdf,.doc,.docx,application/pdf">
      <?php if ($me['resume_path']): ?><div class="muted sm">Choose a new file only if you want to replace the current resume.</div><?php endif; ?></div>
    <label class="field full"><span>About me</span><textarea name="about" rows="3"><?= e($me['about']) ?></textarea></label>
  </div>
  <button class="btn primary">Save profile</button>
</form>
<?= password_card_html() ?>
<?php page_end();
