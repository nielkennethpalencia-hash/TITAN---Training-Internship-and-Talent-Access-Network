<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('student');
$pdo = db();
$me = current_student();
$id = (int)($_GET['id'] ?? $_POST['company_id'] ?? 0);

$c = $pdo->prepare("SELECT c.*, u.email FROM companies c JOIN users u ON u.id=c.user_id WHERE c.id=? AND u.status='approved'");
$c->execute([$id]);
$co = $c->fetch();
if (!$co) { flash('err', 'Company not found'); redirect('student/index.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $pdo->prepare("INSERT INTO recommendations(student_id,company_id,recommended_by,match_score) VALUES(?,?,'student',?)")
            ->execute([$me['id'], $co['id'], match_score($me['skills'], $co['required_skills'])]);
        flash('ok', 'Application sent to ' . $co['company_name']);
    } catch (PDOException $ex) {
        flash('err', $ex->getCode() == 23000 ? 'You already applied to this company' : $ex->getMessage());
    }
    redirect('student/company.php?id=' . $id);
}
$st = $pdo->prepare('SELECT * FROM recommendations WHERE student_id=? AND company_id=?');
$st->execute([$me['id'], $id]);
$rec = $st->fetch();
$score = match_score($me['skills'], $co['required_skills']);

page_start($co['company_name'], student_tabs(), 'index.php');
?>
<p><a href="index.php">← Back to companies</a></p>
<div class="page-head"><div class="who"><?= av((int)$co['user_id'], $co['company_name'], 72, true) ?><div><h1><?= e($co['company_name']) ?></h1><p class="muted"><?= e($co['industry'] ?: 'Company') ?></p></div></div>
  <div><?php if ($rec): echo '<div class="btn-row">' . badge_html($rec['status']) . cancel_form($rec, 'company') . '</div>'; else: ?>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="company_id" value="<?= $id ?>"><button class="btn primary">Apply</button></form><?php endif; ?></div></div>
<?php if ($rec && $rec['status'] === 'accepted'): ?><div class="flash ok">🎉 You've been accepted. <strong>Interview:</strong> <?= interview_html($rec) ?></div><?php endif; ?>
<div class="split">
  <div class="card"><div class="card-head"><h3>About the company</h3></div>
    <?= $co['description'] ? '<p>' . nl2br(e($co['description'])) . '</p>' : '<p class="muted">No description yet.</p>' ?>
    <div class="muted sm">Skills needed</div><?= skills_html($co['required_skills']) ?></div>
  <div class="card"><div class="card-head"><h3>Details</h3></div>
    <p><span class="muted sm">Industry</span><br><?= e($co['industry'] ?: '-') ?></p>
    <p><span class="muted sm">Address</span><br><?= e($co['address'] ?: '-') ?></p>
    <p><span class="muted sm">Contact number</span><br><?= e($co['phone'] ?: '-') ?></p>
    <p><span class="muted sm">Email</span><br><?= e($co['email']) ?></p>
    <p><span class="muted sm">Slots available</span><br><?= (int)$co['slots'] ?></p>
    <div class="muted sm">Your match</div><?= score_html($score) ?></div>
</div>
<?php page_end();
