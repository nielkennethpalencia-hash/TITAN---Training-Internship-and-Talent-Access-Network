<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $a = post('action');
        if ($a === 'add') {
            $pass = post('password') ?: temp_password();
            $pdo->beginTransaction();
            $uid = create_user(post('name'), post('email'), $pass, 'student', true);
            $pdo->prepare('INSERT INTO students(user_id,student_id,course,year_level,phone,skills) VALUES(?,?,?,?,?,?)')
                ->execute([$uid, post('student_id'), post('course'), post('year_level'), post('phone'), normalize_skills(post('skills'))]);
            $pdo->commit();
            send_mail(strtolower(post('email')), 'Your InternHub account', credentials_email(post('name'), strtolower(post('email')), $pass, 'student'));
            flash('ok', 'Student added. Login email: ' . strtolower(post('email')) . ' | Temporary password: ' . $pass . ' (they must change it on first login)');
        } elseif ($a === 'update') {
            $id = (int)post('id');
            $pdo->prepare('UPDATE students SET student_id=?, course=?, year_level=?, phone=?, skills=? WHERE id=?')
                ->execute([post('student_id'), post('course'), post('year_level'), post('phone'), normalize_skills(post('skills')), $id]);
            if (post('name') !== '') $pdo->prepare('UPDATE users SET name=? WHERE id=(SELECT user_id FROM students WHERE id=?)')->execute([post('name'), $id]);
            flash('ok', 'Student updated');
        } elseif ($a === 'delete') {
            $pdo->prepare('DELETE FROM users WHERE id=(SELECT user_id FROM students WHERE id=?)')->execute([(int)post('id')]);
            flash('ok', 'Student removed');
        }
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('err', $ex->getMessage());
    }
    redirect('admin/students.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare('SELECT s.*, u.name, u.email FROM students s JOIN users u ON u.id=s.user_id WHERE s.id=?');
    $s->execute([(int)$_GET['edit']]);
    $edit = $s->fetch() ?: null;
}
$list = $pdo->query("SELECT s.*, s.id AS student_pk, u.name, u.email,
    EXISTS(SELECT 1 FROM recommendations r WHERE r.student_id=s.id AND r.status='accepted') AS placed
    FROM students s JOIN users u ON u.id=s.user_id WHERE u.status='approved' ORDER BY s.id DESC")->fetchAll();

page_start('Students', admin_tabs(), 'students.php');
$v = fn($k) => e($edit[$k] ?? '');
?>
<div class="page-head"><div><h1>Students</h1><p class="muted">Add students and keep their skills up to date</p></div></div>

<form class="card" method="post">
  <div class="card-head"><h3><?= $edit ? 'Edit student' : 'Add student' ?></h3><?php if ($edit): ?><a class="btn sm" href="students.php">Cancel</a><?php endif; ?></div>
  <?= csrf_field() ?><input type="hidden" name="action" value="<?= $edit ? 'update' : 'add' ?>"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
  <div class="grid3">
    <label class="field"><span>Full name</span><input name="name" required value="<?= $v('name') ?>"></label>
    <label class="field"><span>Student ID</span><input name="student_id" value="<?= $v('student_id') ?>"></label>
    <label class="field"><span>Course</span><?= course_select($edit['course'] ?? '') ?></label>
    <label class="field"><span>Year level</span><?= year_select($edit['year_level'] ?? '') ?></label>
    <label class="field"><span>Phone</span><input name="phone" value="<?= $v('phone') ?>"></label>
    <label class="field"><span>Skills (comma separated)</span><input name="skills" value="<?= $v('skills') ?>"></label>
    <?php if (!$edit): ?>
    <label class="field"><span>Login email</span><input type="email" name="email" required></label>
    <label class="field"><span>Temporary password (optional)</span><input name="password" placeholder="Auto-generate"></label>
    <?php endif; ?>
  </div>
  <button class="btn primary"><?= $edit ? 'Save changes' : '+ Add student' ?></button>
</form>

<div class="card"><h3>All students (<?= count($list) ?>)</h3>
<?php if (!$list): ?><div class="empty">No students yet.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Course</th><th>Skills</th><th>Resume</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($list as $s): ?>
<tr<?= modal_student((int)$s['user_id']) ?>><td><?= who_html((int)$s['user_id'], $s['name'], e($s['email']) . ($s['student_id'] ? ' · ' . e($s['student_id']) : '')) ?></td>
<td><?= e($s['course'] ?: '-') ?><div class="muted sm"><?= e($s['year_level']) ?></div></td>
<td><?= skills_html($s['skills']) ?></td>
<td><?= resume_link($s) ?></td>
<td><?= $s['placed'] ? badge_html('accepted') : '<span class="muted">Not placed</span>' ?></td>
<td class="actions"><a class="btn sm" href="?edit=<?= (int)$s['id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('Remove this student and their account?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn sm danger">Remove</button></form></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php page_end();
