<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $a = post('action');
    if ($a === 'archive') { $pdo->prepare('UPDATE recommendations SET archived=1 WHERE id=?')->execute([(int)post('id')]); flash('ok', 'Recommendation archived'); }
    elseif ($a === 'restore') { $pdo->prepare('UPDATE recommendations SET archived=0 WHERE id=?')->execute([(int)post('id')]); flash('ok', 'Recommendation restored'); }
    redirect('admin/recommendations.php' . (post('view') === 'archived' ? '?view=archived' : ''));
}
$view = ($_GET['view'] ?? '') === 'archived' ? 'archived' : 'active';
$recs = $pdo->prepare("SELECT r.*, u.name AS student_name, s.user_id AS suid, c.user_id AS cuid, c.company_name FROM recommendations r
    JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id JOIN companies c ON c.id=r.company_id WHERE r.archived=? ORDER BY r.created_at DESC");
$recs->execute([$view === 'archived' ? 1 : 0]);
$recs = $recs->fetchAll();
$archivedCount = (int)$pdo->query('SELECT COUNT(*) FROM recommendations WHERE archived=1')->fetchColumn();
page_start('Recommendations', admin_tabs(), 'recommendations.php');
?>
<div class="page-head"><div><h1>Recommendations</h1><p class="muted">Every student–company recommendation and its response</p></div></div>
<div class="seg" style="max-width:360px;margin-top:0"><a class="<?= $view === 'active' ? 'on' : '' ?>" href="recommendations.php">Active</a><a class="<?= $view === 'archived' ? 'on' : '' ?>" href="?view=archived">Archived (<?= $archivedCount ?>)</a></div>
<div class="card">
<?php if (!$recs): ?><div class="empty"><?= $view === 'archived' ? 'No archived recommendations.' : 'No recommendations yet.' ?></div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Student</th><th>Company</th><th>By</th><th>Match</th><th>Status</th><th>Interview</th><th></th></tr></thead><tbody>
<?php foreach ($recs as $r): ?>
<tr><td><?= who_html((int)$r['suid'], $r['student_name'], '', false, 32, modal_student((int)$r['suid'])) ?></td><td><?= who_html((int)$r['cuid'], $r['company_name'], '', true, 32, modal_company((int)$r['cuid'])) ?></td><td class="cap"><?= e($r['recommended_by']) ?></td>
<td><?= score_html($r['match_score']) ?></td><td><?= badge_html($r['status']) ?></td><td><?= interview_html($r) ?></td>
<td class="actions"><form method="post" class="inline"<?= $view === 'active' ? ' onsubmit="return confirm(\'Archive this recommendation?\')"' : '' ?>><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="view" value="<?= e($view) ?>">
<?php if ($view === 'active'): ?><button class="btn sm" name="action" value="archive">Archive</button><?php else: ?><button class="btn sm primary" name="action" value="restore">Restore</button><?php endif; ?></form></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php page_end();
