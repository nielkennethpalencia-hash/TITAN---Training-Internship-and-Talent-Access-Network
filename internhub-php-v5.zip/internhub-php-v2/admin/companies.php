<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $a = post('action');
        if ($a === 'add') {
            $pass = post('password') ?: temp_password();
            $pdo->beginTransaction();
            $uid = create_user(post('company_name'), post('email'), $pass, 'company', true);
            $pdo->prepare('INSERT INTO companies(user_id,company_name,industry,address,phone,description,required_skills,slots) VALUES(?,?,?,?,?,?,?,?)')
                ->execute([$uid, post('company_name'), post('industry'), post('address'), post('phone'), post('description'), normalize_skills(post('required_skills')), max(0, (int)post('slots'))]);
            $pdo->commit();
            send_mail(strtolower(post('email')), 'Your InternHub account', credentials_email(post('company_name'), strtolower(post('email')), $pass, 'company'));
            flash('ok', 'Company added. Login email: ' . strtolower(post('email')) . ' | Temporary password: ' . $pass . ' (they must change it on first login)');
        } elseif ($a === 'update') {
            $id = (int)post('id');
            $pdo->prepare('UPDATE companies SET company_name=?, industry=?, address=?, phone=?, description=?, required_skills=?, slots=? WHERE id=?')
                ->execute([post('company_name'), post('industry'), post('address'), post('phone'), post('description'), normalize_skills(post('required_skills')), max(0, (int)post('slots')), $id]);
            $pdo->prepare('UPDATE users SET name=? WHERE id=(SELECT user_id FROM companies WHERE id=?)')->execute([post('company_name'), $id]);
            flash('ok', 'Company updated');
        } elseif ($a === 'delete') {
            $pdo->prepare('DELETE FROM users WHERE id=(SELECT user_id FROM companies WHERE id=?)')->execute([(int)post('id')]);
            flash('ok', 'Company removed');
        }
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('err', $ex->getMessage());
    }
    redirect('admin/companies.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare('SELECT c.*, u.email FROM companies c JOIN users u ON u.id=c.user_id WHERE c.id=?');
    $s->execute([(int)$_GET['edit']]);
    $edit = $s->fetch() ?: null;
}
$list = $pdo->query("SELECT c.*, u.email FROM companies c JOIN users u ON u.id=c.user_id WHERE u.status='approved' ORDER BY c.id DESC")->fetchAll();

page_start('Companies', admin_tabs(), 'companies.php');
$v = fn($k) => e($edit[$k] ?? '');
?>
<div class="page-head"><div><h1>Companies</h1><p class="muted">Add partner companies and the skills they need</p></div></div>

<form class="card" method="post">
  <div class="card-head"><h3><?= $edit ? 'Edit company' : 'Add company' ?></h3><?php if ($edit): ?><a class="btn sm" href="companies.php">Cancel</a><?php endif; ?></div>
  <?= csrf_field() ?><input type="hidden" name="action" value="<?= $edit ? 'update' : 'add' ?>"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
  <div class="grid3">
    <label class="field"><span>Company name</span><input name="company_name" required value="<?= $v('company_name') ?>"></label>
    <label class="field"><span>Industry</span><input name="industry" value="<?= $v('industry') ?>"></label>
    <label class="field"><span>Phone</span><input name="phone" value="<?= $v('phone') ?>"></label>
    <label class="field"><span>Address</span><input name="address" value="<?= $v('address') ?>"></label>
    <label class="field"><span>Slots</span><input type="number" min="0" name="slots" value="<?= $edit ? (int)$edit['slots'] : 1 ?>"></label>
    <label class="field"><span>Skills needed (comma separated)</span><input name="required_skills" value="<?= $v('required_skills') ?>"></label>
    <label class="field full3"><span>Description</span><input name="description" value="<?= $v('description') ?>"></label>
    <?php if (!$edit): ?>
    <label class="field"><span>Login email</span><input type="email" name="email" required></label>
    <label class="field"><span>Temporary password (optional)</span><input name="password" placeholder="Auto-generate"></label>
    <?php endif; ?>
  </div>
  <button class="btn primary"><?= $edit ? 'Save changes' : '+ Add company' ?></button>
</form>

<div class="card"><h3>All companies (<?= count($list) ?>)</h3>
<?php if (!$list): ?><div class="empty">No companies yet.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Company</th><th>Industry</th><th>Skills needed</th><th>Slots</th><th></th></tr></thead><tbody>
<?php foreach ($list as $c): ?>
<tr<?= modal_company((int)$c['user_id']) ?>><td><?= who_html((int)$c['user_id'], $c['company_name'], e($c['email']), true) ?></td>
<td><?= e($c['industry'] ?: '-') ?><div class="muted sm"><?= e($c['address']) ?></div></td>
<td><?= skills_html($c['required_skills']) ?></td><td><?= (int)$c['slots'] ?></td>
<td class="actions"><a class="btn sm" href="?edit=<?= (int)$c['id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('Remove this company and its account?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><button class="btn sm danger">Remove</button></form></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php page_end();
