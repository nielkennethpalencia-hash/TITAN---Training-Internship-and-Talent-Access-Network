<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$pdo = db();
$n = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
$stats = [
    ['Students', $n("SELECT COUNT(*) FROM students s JOIN users u ON u.id=s.user_id WHERE u.status='approved'"), ''],
    ['Companies', $n("SELECT COUNT(*) FROM companies c JOIN users u ON u.id=c.user_id WHERE u.status='approved'"), ''],
    ['Placed students', $n("SELECT COUNT(DISTINCT student_id) FROM recommendations WHERE status='accepted'"), 'green'],
    ['Pending responses', $n("SELECT COUNT(*) FROM recommendations WHERE status='pending'"), 'amber'],
    ['Accepted', $n("SELECT COUNT(*) FROM recommendations WHERE status='accepted'"), 'green'],
    ['Rejected', $n("SELECT COUNT(*) FROM recommendations WHERE status='rejected'"), 'red'],
];
$recs = $pdo->query("SELECT r.*, u.name AS student_name, s.user_id AS suid, c.user_id AS cuid, c.company_name FROM recommendations r
    JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id JOIN companies c ON c.id=r.company_id
    WHERE r.archived=0 ORDER BY r.created_at DESC LIMIT 6")->fetchAll();

page_start('Dashboard', admin_tabs(), 'index.php');
?>
<div class="page-head"><div><h1>Dashboard</h1><p class="muted">Manage students, companies and internship placements</p></div></div>
<div class="stats">
<?php foreach ($stats as [$label, $val, $tone]): ?>
  <div class="stat <?= $tone ?>"><div class="num"><?= $val ?></div><div class="lbl"><?= e($label) ?></div></div>
<?php endforeach; ?>
</div>
<div class="card"><h3>Latest recommendations</h3>
<?php if (!$recs): ?><div class="empty">No recommendations yet.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Student</th><th>Company</th><th>By</th><th>Match</th><th>Status</th><th>Interview</th></tr></thead><tbody>
<?php foreach ($recs as $r): ?>
<tr><td><?= who_html((int)$r['suid'], $r['student_name'], '', false, 32, modal_student((int)$r['suid'])) ?></td><td><?= who_html((int)$r['cuid'], $r['company_name'], '', true, 32, modal_company((int)$r['cuid'])) ?></td><td class="cap"><?= e($r['recommended_by']) ?></td>
<td><?= score_html($r['match_score']) ?></td><td><?= badge_html($r['status']) ?></td><td><?= interview_html($r) ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php page_end();
