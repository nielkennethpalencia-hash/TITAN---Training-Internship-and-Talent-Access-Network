<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)post('id');
    $q = $pdo->prepare("SELECT * FROM users WHERE id=? AND role IN ('student','company')");
    $q->execute([$id]);
    if ($u = $q->fetch()) {
        $a = post('action');
        if ($a === 'approve') {
            $pdo->prepare("UPDATE users SET status='approved' WHERE id=?")->execute([$id]);
            $sent = send_mail($u['email'], 'Your InternHub account is approved', approved_email($u['name'], $u['role']));
            flash('ok', $u['name'] . ' approved.' . ($sent ? ' An email was sent.' : ' (Email not sent: ' . last_mail_error() . ')'));
        } elseif ($a === 'decline') {
            $pdo->prepare("UPDATE users SET status='rejected' WHERE id=?")->execute([$id]);
            send_mail($u['email'], 'InternHub registration update', declined_email($u['name']));
            flash('ok', $u['name'] . ' was declined.');
        } elseif ($a === 'delete') {
            $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]);
            flash('ok', 'Registration deleted.');
        }
    }
    redirect('admin/approvals.php');
}

$fetch = function (string $status) use ($pdo) {
    $q = $pdo->prepare("SELECT u.*, s.course, s.year_level, s.skills, c.company_name, c.industry, c.address, c.required_skills
        FROM users u LEFT JOIN students s ON s.user_id=u.id LEFT JOIN companies c ON c.user_id=u.id
        WHERE u.role IN ('student','company') AND u.status=? ORDER BY u.created_at DESC");
    $q->execute([$status]);
    return $q->fetchAll();
};
$pending = $fetch('pending');
$declined = $fetch('rejected');

$row = function (array $u, bool $isPending) {
    $isStu = $u['role'] === 'student';
    echo '<tr' . ($isStu ? modal_student((int)$u['id']) : modal_company((int)$u['id'])) . '><td>' . who_html((int)$u['id'], $u['name'], e($u['email']), !$isStu) . '</td>';
    echo '<td><span class="badge ' . ($isStu ? 'role-student' : 'role-company') . '">' . ($isStu ? 'Student' : 'Company') . '</span></td><td>';
    if ($isStu) echo e($u['course'] ?: '-') . ($u['year_level'] ? ' · ' . e($u['year_level']) : '') . skills_html($u['skills']);
    else echo e($u['industry'] ?: '-') . ($u['address'] ? '<div class="muted sm">' . e($u['address']) . '</div>' : '') . skills_html($u['required_skills']);
    echo '</td><td class="muted sm">' . e(date('M j, Y g:i A', strtotime($u['created_at']))) . '</td><td class="actions">';
    echo '<form method="post" class="inline">' . csrf_field() . '<input type="hidden" name="id" value="' . (int)$u['id'] . '">';
    echo '<button class="btn sm primary" name="action" value="approve">Approve</button> ';
    if ($isPending) echo '<button class="btn sm danger" name="action" value="decline" onclick="return confirm(\'Decline this registration?\')">Decline</button>';
    else echo '<button class="btn sm danger" name="action" value="delete" onclick="return confirm(\'Delete this registration permanently?\')">Delete</button>';
    echo '</form></td></tr>';
};

page_start('Approvals', admin_tabs(), 'approvals.php');
?>
<div class="page-head"><div><h1>Account approvals</h1><p class="muted">Students and companies that registered themselves must be approved before they can log in</p></div></div>
<div class="card"><div class="card-head"><h3>Waiting for approval (<?= count($pending) ?>)</h3></div>
<?php if (!$pending): ?><div class="empty">No registrations are waiting. 🎉</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Type</th><th>Details</th><th>Registered</th><th></th></tr></thead><tbody>
<?php foreach ($pending as $u) $row($u, true); ?></tbody></table></div><?php endif; ?></div>

<?php if ($declined): ?>
<div class="card"><div class="card-head"><h3>Declined (<?= count($declined) ?>)</h3></div>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Type</th><th>Details</th><th>Registered</th><th></th></tr></thead><tbody>
<?php foreach ($declined as $u) $row($u, false); ?></tbody></table></div></div>
<?php endif; ?>
<?php page_end();
