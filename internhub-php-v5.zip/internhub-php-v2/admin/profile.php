<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'password') handle_password_change();
    redirect('admin/profile.php');
}
$me = db()->prepare('SELECT name, email FROM users WHERE id=?'); $me->execute([$_SESSION['uid']]); $me = $me->fetch();
page_start('My profile', admin_tabs(), 'profile.php');
?>
<div class="page-head"><div><h1>My profile</h1><p class="muted">Your account and password</p></div></div>
<div class="card" style="max-width:520px"><div class="grid2">
  <label class="field"><span>Name</span><input value="<?= e($me['name']) ?>" disabled></label>
  <label class="field"><span>Email</span><input value="<?= e($me['email']) ?>" disabled></label>
</div></div>
<?= password_card_html() ?>
<?php page_end();
