<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');
$pdo = db();
$filter = (int)($_GET['company_id'] ?? $_POST['filter'] ?? 0);   // 0 = show every company

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $sid = (int)post('student_id'); $companyId = (int)post('company_id');
        $s = $pdo->prepare('SELECT skills FROM students WHERE id=?'); $s->execute([$sid]); $stu = $s->fetch();
        $c = $pdo->prepare('SELECT required_skills FROM companies WHERE id=?'); $c->execute([$companyId]); $co = $c->fetch();
        if (!$stu || !$co) throw new Exception('Student or company not found');
        $pdo->prepare("INSERT INTO recommendations(student_id,company_id,recommended_by,match_score) VALUES(?,?,'admin',?)")
            ->execute([$sid, $companyId, match_score($stu['skills'], $co['required_skills'])]);
        flash('ok', 'Student recommended to the company');
    } catch (PDOException $ex) {
        flash('err', $ex->getCode() == 23000 ? 'This student was already recommended to this company' : $ex->getMessage());
    } catch (Throwable $ex) { flash('err', $ex->getMessage()); }
    redirect('admin/matching.php' . ($filter ? '?company_id=' . $filter : ''));
}

$companies = $pdo->query("SELECT c.* FROM companies c JOIN users u ON u.id=c.user_id WHERE u.status='approved' ORDER BY c.company_name")->fetchAll();
$show = $filter ? array_values(array_filter($companies, fn($c) => (int)$c['id'] === $filter)) : $companies;
$students = $pdo->query("SELECT s.*, s.id AS student_pk, u.name FROM students s JOIN users u ON u.id=s.user_id WHERE u.status='approved'")->fetchAll();
$recd = [];
foreach ($pdo->query('SELECT student_id, company_id FROM recommendations')->fetchAll() as $r) $recd[$r['company_id']][$r['student_id']] = true;

page_start('Matching', admin_tabs(), 'matching.php');
?>
<div class="page-head"><div><h1>Matching</h1><p class="muted">See which students best fit each company, then recommend them</p></div></div>
<div class="card">
  <form method="get"><label class="field" style="margin:0"><span>Filter by company</span>
    <select name="company_id" onchange="this.form.submit()"><option value="">All companies (<?= count($companies) ?>)</option>
    <?php foreach ($companies as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $c['id'] == $filter ? 'selected' : '' ?>><?= e($c['company_name']) ?></option><?php endforeach; ?>
    </select></label></form>
</div>
<?php if (!$show): ?><div class="card"><div class="empty">No companies yet. Add one in the Companies tab.</div></div><?php endif; ?>
<?php foreach ($show as $company):
    $rows = [];
    foreach ($students as $s) { $s['score'] = match_score($s['skills'], $company['required_skills']); $s['recommended'] = isset($recd[$company['id']][$s['id']]); $rows[] = $s; }
    usort($rows, fn($a, $b) => $b['score'] <=> $a['score']); ?>
<div class="card">
  <div class="card-head"<?= modal_company((int)$company['user_id']) ?>><?= who_html((int)$company['user_id'], $company['company_name'], e($company['industry']) . ($company['address'] ? ' · ' . e($company['address']) : ''), true, 48) ?></div>
  <div class="muted sm">Skills needed</div><?= skills_html($company['required_skills']) ?>
  <?php if (!$rows): ?><div class="empty">No students available.</div><?php else: ?>
  <div class="table-wrap"><table><thead><tr><th>Student</th><th>Skills</th><th>Resume</th><th>Match</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $s): ?>
    <tr<?= modal_student((int)$s['user_id']) ?>><td><?= who_html((int)$s['user_id'], $s['name'], e($s['course'])) ?></td><td><?= skills_html($s['skills']) ?></td><td><?= resume_link($s) ?></td><td><?= score_html($s['score']) ?></td>
    <td class="actions"><?php if ($s['recommended']): ?><span class="muted">Already recommended</span><?php else: ?>
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="company_id" value="<?= (int)$company['id'] ?>"><input type="hidden" name="filter" value="<?= $filter ?>"><input type="hidden" name="student_id" value="<?= (int)$s['id'] ?>"><button class="btn sm primary">Recommend</button></form><?php endif; ?></td></tr>
  <?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php endforeach; ?>
<?php page_end();
