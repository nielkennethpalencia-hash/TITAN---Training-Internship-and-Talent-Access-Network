<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $a = post('action');
    if ($a === 'save') {
        $user = post('smtp_user');
        $pass = str_replace(' ', '', post('smtp_pass'));
        if ($user !== '' && !filter_var($user, FILTER_VALIDATE_EMAIL)) flash('err', 'Please enter a valid Gmail address');
        else {
            set_setting('smtp_user', $user);
            set_setting('smtp_from_name', post('smtp_from_name') ?: 'InternHub');
            if ($pass !== '') set_setting('smtp_pass', $pass);          // blank = keep the saved password
            flash('ok', 'Email settings saved. Click "Send test email" to check that it works.');
        }
    } elseif ($a === 'clear') {
        set_setting('smtp_user', ''); set_setting('smtp_pass', '');
        flash('ok', 'Email settings removed.');
    } elseif ($a === 'test') {
        $to = post('test_to');
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) flash('err', 'Enter a valid email address to send the test to');
        elseif (send_mail($to, 'InternHub test email', email_shell('<h3 style="margin-top:0">It works! ✅</h3><p>Your InternHub email settings are correct. Students will now be emailed when a company accepts them.</p>')))
            flash('ok', "Test email sent to $to. Check the inbox (and the Spam folder).");
        else flash('err', 'Test email failed: ' . last_mail_error());
    }
    redirect('admin/settings.php');
}

$me = db()->prepare('SELECT email FROM users WHERE id=?'); $me->execute([$_SESSION['uid']]); $myEmail = $me->fetchColumn();
$cfg = smtp_config();
page_start('Email settings', admin_tabs(), 'settings.php');
?>
<div class="page-head"><div><h1>Email settings</h1><p class="muted">Used to email students when a company accepts them, and to notify approved accounts</p></div></div>

<div class="card status-card <?= mail_ready() ? 'ok' : 'warn' ?>">
  <strong><?= mail_ready() ? '✅ Email is set up' : '⚠️ Email is not set up yet' ?></strong>
  <div class="muted"><?= mail_ready() ? 'Sending from ' . e($cfg['user']) : 'Students will NOT receive emails until you save a Gmail address and App password below.' ?></div>
</div>

<div class="split">
<form class="card" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="save">
  <div class="card-head"><h3>Gmail account</h3></div>
  <label class="field"><span>Gmail address</span><input type="email" name="smtp_user" placeholder="youraccount@gmail.com" value="<?= e(get_setting('smtp_user')) ?>" required></label>
  <label class="field"><span>Gmail App password</span><input type="password" name="smtp_pass" autocomplete="new-password" placeholder="<?= get_setting('smtp_pass') !== '' ? '•••••••••••••••• (saved - leave blank to keep)' : '16-character app password' ?>" <?= get_setting('smtp_pass') === '' ? 'required' : '' ?>></label>
  <label class="field"><span>Sender name</span><input name="smtp_from_name" value="<?= e(get_setting('smtp_from_name', 'InternHub')) ?>"></label>
  <button class="btn primary">Save settings</button>
</form>

<div>
  <form class="card" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="test">
    <div class="card-head"><h3>Send a test email</h3></div>
    <label class="field"><span>Send to</span><input type="email" name="test_to" value="<?= e($myEmail) ?>" required></label>
    <button class="btn">Send test email</button>
  </form>
  <div class="card howto"><h3>How to get a Gmail App password</h3>
    <ol>
      <li>Open your Google Account → <b>Security</b>.</li>
      <li>Turn on <b>2-Step Verification</b>.</li>
      <li>Search for <b>App passwords</b>, create one named "InternHub".</li>
      <li>Copy the 16-character code (spaces don't matter) and paste it here.</li>
    </ol>
    <p class="muted sm">Use the App password, not your normal Gmail password. It is stored in your database.</p>
    <?php if (mail_ready()): ?><form method="post" onsubmit="return confirm('Remove the saved email settings?')"><?= csrf_field() ?><input type="hidden" name="action" value="clear"><button class="btn sm danger">Remove saved settings</button></form><?php endif; ?>
  </div>
</div>
</div>
<?php page_end();
