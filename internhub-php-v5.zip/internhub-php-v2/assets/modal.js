(function () {
  // Any element with data-modal="ID" opens <template id="ID"> in a pop-up.
  var IGNORE = 'button, form, a, input, select, textarea, label, summary, details, .interview-box';
  function openModal(id, opener) {
    var t = document.getElementById(id); if (!t) return;
    var back = document.createElement('div'); back.className = 'modal-back';
    var m = document.createElement('div'); m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.appendChild(t.content.cloneNode(true));
    var x = document.createElement('button'); x.className = 'modal-x'; x.type = 'button'; x.setAttribute('aria-label', 'Close'); x.innerHTML = '&times;'; m.appendChild(x);
    back.appendChild(m); document.body.appendChild(back); document.body.style.overflow = 'hidden'; x.focus();
    function close() { back.remove(); document.body.style.overflow = ''; document.removeEventListener('keydown', key); if (opener && opener.focus) opener.focus(); }
    function key(e) { if (e.key === 'Escape') close(); }
    x.onclick = close; back.addEventListener('click', function (e) { if (e.target === back) close(); }); document.addEventListener('keydown', key);
  }
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-modal]'); if (!t || e.target.closest('.modal')) return;
    var inner = e.target.closest(IGNORE); if (inner && t.contains(inner)) return;
    openModal(t.getAttribute('data-modal'), t);
  });
  document.addEventListener('keydown', function (e) {
    var t = e.target; if ((e.key === 'Enter' || e.key === ' ') && t.matches && t.matches('[data-modal]')) { e.preventDefault(); openModal(t.getAttribute('data-modal'), t); }
  });
})();
