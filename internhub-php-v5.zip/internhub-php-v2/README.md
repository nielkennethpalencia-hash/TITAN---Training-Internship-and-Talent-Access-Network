# InternHub – PHP + MySQL (v2)

Roles: **Admin (head teacher)**, **Company**, **Student**.
Login / logout (20-minute session), admin approval of new accounts, skill matching, accept/reject with an
interview schedule, and a **Gmail email to the student when accepted**.

## Run with XAMPP
1. Install **XAMPP** (PHP 8.1+). Start **Apache** and **MySQL**.
2. Copy the `internhub-php-v2` folder into `htdocs`.
3. Open **http://localhost/internhub-php-v2/** – the database, tables and admin account are created automatically.
4. Admin login: **admin@school.edu** / **Admin@12345** (change in `config.php` before first run, or change the password after login).

> Upgrading from the old version? Copy this folder over it. Old data is kept; new columns/tables are added automatically.
> Existing accounts stay approved.

## Set up Gmail (important for the "accepted" email)
Log in as admin → **Email settings** → enter your Gmail address + a Google **App password** → **Save** → **Send test email**.
The test shows the exact error if something is wrong. No file editing needed.
(Get an App password: Google Account → Security → turn on 2-Step Verification → App passwords.)

## Account approval
- Students and companies can register themselves, but they **cannot log in until the admin approves** them
  (Admin → **Approvals**; a counter shows how many are waiting). They get an email when approved.
- Accounts the admin creates directly are active immediately (temporary password, changed on first login).

## What's new in this version
- **Matching**: shows every company with its ranked students by default; the dropdown only filters to one company.
- **Recommendations (admin)**: *Delete* is now **Archive** (with an Archived tab and Restore).
- **Student**: *Recommend me* → **Apply**; companies are clickable (details page); new **Schedule** tab; Profile has Course/Year dropdowns, **resume upload** (PDF/DOC/DOCX, max 5 MB, stored in `storage/resumes`) instead of the skills box.
- **Company**: new **Schedule** tab for interviews (upcoming / needs schedule / past, with reschedule).
- **Change password** is only in each role's **My profile** page (the standalone page is used only for the forced first-login change).
- **Registration**: students and companies can both register themselves (admin approves them); the admin can also add companies directly. Register page has a Back to login button.
- **Student Companies tab**: clicking a company card opens a pop-up with the full company information and the Apply button.
- **Pictures**: students upload a profile picture and companies a logo (My profile → JPG/PNG/GIF/WEBP, max 2 MB, stored in `storage/avatars`). They show in the sidebar and in every list (a coloured initial is shown if none is uploaded).
- **Cancel application**: students can cancel any application (My requests, the company card, or its pop-up) and apply again later.
- **Remove**: students can remove their resume and picture; companies can remove their logo (My profile).
- **Full-information pop-ups**: click a student or company card/row (company Candidates/Schedule/History, admin Approvals/Students/Companies/Matching/Recommendations, student My requests/Schedule) to see everything.
- Skills are still used for match scores: set at registration or edited by the admin (Students tab).

## Demo flow
1. Register a student and a company from the login page → log in as admin → **Approvals** → approve both.
2. Admin → **Matching** → pick the company → **Recommend** the student.
3. Company logs in → sets the **interview date/time/place** → **Accept**. The student is emailed the schedule.
4. The student sees the schedule on their dashboard and in **My requests**.

## Files
```
index.php  register.php  logout.php  change_password.php
admin/    index · approvals · students · companies · matching · recommendations · settings
student/  index · requests · profile        company/  index · history · profile
includes/ bootstrap.php · mail.php (SMTP)   assets/style.css   database.sql   config.php
```
