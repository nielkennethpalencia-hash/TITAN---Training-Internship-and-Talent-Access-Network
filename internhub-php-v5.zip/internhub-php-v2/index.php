<?php
require __DIR__ . '/includes/bootstrap.php';
if (user()) redirect($_SESSION['must_change'] ? 'change_password.php' : home_for($_SESSION['role']));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $s = db()->prepare('SELECT * FROM users WHERE email=?');
    $s->execute([strtolower(post('email'))]);
    $u = $s->fetch();
    if ($u && password_verify((string)($_POST['password'] ?? ''), $u['password'])) {
        if ($u['status'] === 'pending') flash('err', 'Your account is waiting for the head teacher to approve it. You will get an email once it is approved.');
        elseif ($u['status'] === 'rejected') flash('err', 'Your registration was not approved. Please contact the head teacher.');
        else {
            login_user($u);
            redirect($u['must_change'] ? 'change_password.php' : home_for($u['role']));
        }
        redirect('index.php');
    }
    flash('err', 'Incorrect email or password');
    redirect('index.php');
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Log in - InternHub</title><link rel="stylesheet" href="<?= e(url('assets/style.css')) ?>"></head><body>
<div class="auth-wrap">
  <div class="auth-side">
    <div class="brand big"><span class="logo">IH</span> InternHub</div>
    <h1>Internship placement, simplified.</h1>
    <p>Connect students with the right companies. Track recommendations, responses and placements in one place.</p>
    <ul><li>Skill-based student–company matching</li><li>Instant email when a company accepts</li><li>One dashboard for teachers, students and companies</li></ul>
  </div>
  <form class="auth-card" method="post">
    <h2>Welcome back</h2><p class="muted">Log in to your account</p>
    <?php if (!empty($_SESSION['flash'])) { [$t, $m] = $_SESSION['flash']; unset($_SESSION['flash']); echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>'; } ?>
    <?= csrf_field() ?>
    <label class="field"><span>Email</span><input type="email" name="email" required autofocus></label>
    <label class="field"><span>Password</span><input type="password" name="password" required></label>
    <button class="btn primary block">Log in</button>
    <p class="center muted">New student or company? <a href="register.php">Create an account</a></p>
  </form>
</div></body></html>
