<?php
require __DIR__ . '/includes/bootstrap.php';
if (user()) redirect(home_for($_SESSION['role']));
$role = ($_GET['role'] ?? $_POST['role'] ?? 'student') === 'company' ? 'company' : 'student';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $pdo = db();
        $pdo->beginTransaction();
        $name = $role === 'company' ? post('company_name') : post('name');
        $uid = create_user($name, post('email'), (string)($_POST['password'] ?? ''), $role, false, 'pending');
        if ($role === 'student') {
            $pdo->prepare('INSERT INTO students(user_id,student_id,course,year_level,phone,skills) VALUES(?,?,?,?,?,?)')
                ->execute([$uid, post('student_id'), post('course'), post('year_level'), post('phone'), normalize_skills(post('skills'))]);
        } else {
            $pdo->prepare('INSERT INTO companies(user_id,company_name,industry,address,phone,required_skills,slots) VALUES(?,?,?,?,?,?,?)')
                ->execute([$uid, $name, post('industry'), post('address'), post('phone'), normalize_skills(post('required_skills')), max(0, (int)post('slots'))]);
        }
        $pdo->commit();
        flash('ok', 'Registration received! The head teacher must approve your account first. You will receive an email once it is approved, then you can log in.');
        redirect('index.php');
    } catch (Throwable $ex) {
        if (db()->inTransaction()) db()->rollBack();
        flash('err', $ex->getMessage());
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Register - InternHub</title><link rel="stylesheet" href="<?= e(url('assets/style.css')) ?>"></head><body>
<div class="auth-wrap single">
  <form class="auth-card wide" method="post">
    <p style="margin:0 0 14px"><a class="btn sm" href="index.php">← Back to login</a></p>
    <h2>Create your account</h2><p class="muted">Your account will be activated after the head teacher approves it.</p>
    <div class="seg"><a class="<?= $role === 'student' ? 'on' : '' ?>" href="?role=student">I'm a student</a><a class="<?= $role === 'company' ? 'on' : '' ?>" href="?role=company">I'm a company</a></div>
    <?php if (!empty($_SESSION['flash'])) { [$t, $m] = $_SESSION['flash']; unset($_SESSION['flash']); echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>'; } ?>
    <?= csrf_field() ?><input type="hidden" name="role" value="<?= e($role) ?>">
    <div class="grid2">
    <?php if ($role === 'student'): ?>
      <label class="field"><span>Full name</span><input name="name" required value="<?= e($_POST['name'] ?? '') ?>"></label>
      <label class="field"><span>Student ID</span><input name="student_id" value="<?= e($_POST['student_id'] ?? '') ?>"></label>
      <label class="field"><span>Course</span><?= course_select($_POST['course'] ?? '', true) ?></label>
      <label class="field"><span>Year level</span><?= year_select($_POST['year_level'] ?? '', true) ?></label>
      <label class="field full"><span>Skills (comma separated)</span><input name="skills" placeholder="PHP, MySQL, JavaScript" value="<?= e($_POST['skills'] ?? '') ?>"></label>
    <?php else: ?>
      <label class="field"><span>Company name</span><input name="company_name" required value="<?= e($_POST['company_name'] ?? '') ?>"></label>
      <label class="field"><span>Industry</span><input name="industry" value="<?= e($_POST['industry'] ?? '') ?>"></label>
      <label class="field full"><span>Address</span><input name="address" value="<?= e($_POST['address'] ?? '') ?>"></label>
      <label class="field"><span>Slots available</span><input type="number" min="0" name="slots" value="<?= e($_POST['slots'] ?? '1') ?>"></label>
      <label class="field"><span>Contact number</span><input name="phone" value="<?= e($_POST['phone'] ?? '') ?>"></label>
      <label class="field full"><span>Skills you need (comma separated)</span><input name="required_skills" placeholder="PHP, MySQL, Teamwork" value="<?= e($_POST['required_skills'] ?? '') ?>"></label>
    <?php endif; ?>
      <label class="field"><span>Email</span><input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></label>
      <label class="field"><span>Password</span><input type="password" name="password" minlength="6" required></label>
    </div>
    <button class="btn primary block">Submit registration</button>
    <p class="center muted">Already registered? <a href="index.php">Log in</a></p>
  </form>
</div></body></html>
