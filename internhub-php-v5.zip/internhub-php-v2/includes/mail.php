<?php
$GLOBALS['mail_error'] = '';
function last_mail_error(): string { return $GLOBALS['mail_error'] ?? ''; }

/** SMTP settings: saved in the database (Admin > Email settings) override config.php */
function smtp_config(): array
{
    $c = cfg('smtp');
    $user = get_setting('smtp_user');
    $pass = get_setting('smtp_pass');
    if ($user !== '' && $pass !== '') {
        $c = ['host' => 'smtp.gmail.com', 'port' => 587, 'user' => $user, 'pass' => $pass, 'from' => $user, 'from_name' => get_setting('smtp_from_name', 'InternHub')];
    }
    $c['pass'] = str_replace(' ', '', (string)($c['pass'] ?? ''));   // Google shows app passwords with spaces
    return $c;
}

function mail_ready(): bool { $c = smtp_config(); return !empty($c['host']) && !empty($c['user']) && !empty($c['pass']); }

function mail_log(string $line): void { @file_put_contents(__DIR__ . '/../storage/mail.log', '[' . date('Y-m-d H:i:s') . '] ' . $line . "\n", FILE_APPEND); }

/** Sends an HTML email. Returns true only if the SMTP server accepted it. On failure see last_mail_error(). */
function send_mail(string $to, string $subject, string $html): bool
{
    $GLOBALS['mail_error'] = '';
    if (!mail_ready()) {
        $GLOBALS['mail_error'] = 'Email is not set up yet (Admin > Email settings).';
        mail_log("NOT SENT (no email settings) TO: $to | $subject");
        return false;
    }
    try {
        return smtp_send(smtp_config(), $to, $subject, $html);
    } catch (Throwable $e) {
        $m = $e->getMessage();
        if (preg_match('/\b53[45]\b/', $m)) $m = 'Gmail rejected the login. Use a 16-character App password (not your normal Gmail password) and make sure 2-Step Verification is on.';
        $GLOBALS['mail_error'] = $m;
        mail_log("FAILED TO: $to | $subject | $m");
        return false;
    }
}

function smtp_send(array $c, string $to, string $subject, string $html): bool
{
    if (!extension_loaded('openssl')) throw new Exception('PHP "openssl" is disabled. In XAMPP open php.ini, remove the ; before extension=openssl, then restart Apache.');
    $port = (int)$c['port'];
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]]);
    $fp = @stream_socket_client(($port === 465 ? 'ssl://' : 'tcp://') . $c['host'] . ':' . $port, $en, $es, 20, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) throw new Exception("Cannot connect to {$c['host']}:$port ($es). Check your internet connection or firewall.");
    stream_set_timeout($fp, 20);
    $read = function () use ($fp) {
        $d = '';
        while (($l = fgets($fp, 515)) !== false) { $d .= $l; if (substr($l, 3, 1) === ' ') break; }
        return $d;
    };
    $send = function (string $cmd, string $expect) use ($fp, $read) {
        fwrite($fp, $cmd . "\r\n");
        $r = trim($read());
        if (strpos($r, $expect) !== 0) throw new Exception('SMTP server said: ' . $r);
    };
    $g = trim($read());
    if (strpos($g, '220') !== 0) throw new Exception('SMTP greeting failed: ' . $g);
    $send('EHLO localhost', '250');
    if ($port !== 465) {
        $send('STARTTLS', '220');
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new Exception('Could not start a secure (TLS) connection.');
        $send('EHLO localhost', '250');
    }
    $send('AUTH LOGIN', '334');
    $send(base64_encode($c['user']), '334');
    $send(base64_encode($c['pass']), '235');
    $from = $c['from'] ?: $c['user'];
    $send("MAIL FROM:<$from>", '250');
    $send("RCPT TO:<$to>", '250');
    $send('DATA', '354');
    $fromName = '=?UTF-8?B?' . base64_encode($c['from_name'] ?: 'InternHub') . '?=';
    $msg = "From: $fromName <$from>\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\nDate: " . date('r') . "\r\n"
         . "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
         . chunk_split(base64_encode($html));
    $send($msg . "\r\n.", '250');
    fwrite($fp, "QUIT\r\n");
    fclose($fp);
    mail_log("SENT TO: $to | $subject");
    return true;
}

/* ---------- Email templates ---------- */
function email_shell(string $inner): string
{
    return '<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">'
         . '<div style="background:#0f2a4a;color:#fff;padding:20px 26px"><h2 style="margin:0;font-size:20px">InternHub</h2><div style="opacity:.7;font-size:13px">Internship Portal</div></div>'
         . '<div style="padding:26px;color:#1e293b;line-height:1.6">' . $inner . '</div>'
         . '<div style="background:#f8fafc;padding:12px 26px;color:#94a3b8;font-size:12px">This is an automatic message from InternHub.</div></div>';
}

function accepted_email(string $student, string $company, string $address, ?string $when = null, string $place = '', string $notes = '', bool $rescheduled = false): string
{
    $sched = '';
    if ($when) {
        $sched = '<div style="background:#f0fdfa;border:1px solid #99f6e4;border-radius:8px;padding:14px 16px;margin:16px 0">'
            . '<div style="font-weight:bold;margin-bottom:6px">Face-to-face interview</div>'
            . '<div>Date: <b>' . e(date('l, F j, Y', strtotime($when))) . '</b></div>'
            . '<div>Time: <b>' . e(date('g:i A', strtotime($when))) . '</b></div>'
            . '<div>Place: <b>' . e($place ?: ($address ?: 'To be announced')) . '</b></div>'
            . ($notes ? '<div>Notes: ' . e($notes) . '</div>' : '') . '</div>';
    }
    if ($rescheduled) {
        return email_shell('<h3 style="margin-top:0">Interview schedule updated</h3><p>Hi ' . e($student) . ', <b>' . e($company) . '</b> changed your interview schedule.</p>' . $sched
            . '<p>Please log in to InternHub to see the latest details.</p>');
    }
    return email_shell('<h3 style="margin-top:0">Congratulations, ' . e($student) . '!</h3>'
        . '<p><b>' . e($company) . '</b> has <span style="color:#16a34a;font-weight:bold">accepted</span> you for your internship.</p>'
        . $sched
        . ($address ? '<p>Company address: ' . e($address) . '</p>' : '')
        . '<p>Please arrive on time and bring your resume and a valid ID. Log in to InternHub for details.</p>');
}

function credentials_email(string $name, string $email, string $password, string $role): string
{
    return email_shell('<h3 style="margin-top:0">Welcome, ' . e($name) . '</h3>'
        . "<p>Your head teacher created your $role account.</p>"
        . '<p>Email: <b>' . e($email) . '</b><br>Temporary password: <b>' . e($password) . '</b></p>'
        . '<p>You will be asked to set your own password the first time you log in.</p>');
}

function approved_email(string $name, string $role): string
{
    return email_shell('<h3 style="margin-top:0">Your account is approved ✅</h3><p>Hi ' . e($name) . ', the head teacher approved your ' . e($role) . ' account.</p>'
        . '<p><a href="' . e(site_url('index.php')) . '" style="background:#0d9488;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-weight:bold">Log in now</a></p>');
}

function declined_email(string $name): string
{
    return email_shell('<h3 style="margin-top:0">Registration not approved</h3><p>Hi ' . e($name) . ', unfortunately the head teacher could not approve your registration. '
        . 'Please contact your school for more information.</p>');
}
