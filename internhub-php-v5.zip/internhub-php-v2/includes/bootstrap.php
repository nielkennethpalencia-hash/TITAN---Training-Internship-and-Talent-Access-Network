<?php
require_once __DIR__ . '/mail.php';

function cfg(?string $key = null)
{
    static $c = null;
    $c ??= require __DIR__ . '/../config.php';
    return $key ? $c[$key] : $c;
}

date_default_timezone_set('Asia/Manila');
session_name('internhub');
session_start();

/* ---------- URLs ---------- */
function base_url(): string
{
    static $b = null;
    if ($b === null) {
        $root = str_replace('\\', '/', (string)realpath(__DIR__ . '/..'));
        $doc  = str_replace('\\', '/', (string)realpath($_SERVER['DOCUMENT_ROOT'] ?? ''));
        $b = ($doc !== '' && strpos($root, $doc) === 0) ? substr($root, strlen($doc)) : '';
    }
    return $b;
}
function url(string $path = ''): string { return base_url() . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function home_for(string $role): string { return ['admin' => 'admin/index.php', 'student' => 'student/index.php', 'company' => 'company/index.php'][$role]; }

/* ---------- Escaping / flash / CSRF ---------- */
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function flash(string $type, string $msg): void { $_SESSION['flash'] = [$type, $msg]; }
function csrf_field(): string
{
    $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_check(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) { http_response_code(419); exit('Invalid form token. Go back and try again.'); }
}

/* ---------- Database (auto-creates DB, tables and first admin) ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = cfg('db');
    try {
        $pdo = new PDO("mysql:host={$c['host']};charset=utf8mb4", $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$c['name']}` CHARACTER SET utf8mb4");
        $pdo->exec("USE `{$c['name']}`");
        if (!$pdo->query("SHOW TABLES LIKE 'users'")->fetch()) {
            foreach (array_filter(array_map('trim', explode(';', file_get_contents(__DIR__ . '/../database.sql')))) as $sql) $pdo->exec($sql);
        }
        // upgrade older installs: add interview schedule columns
        if (!$pdo->query("SHOW COLUMNS FROM recommendations LIKE 'interview_at'")->fetch()) {
            $pdo->exec("ALTER TABLE recommendations ADD interview_at DATETIME NULL, ADD interview_place VARCHAR(255) NULL, ADD interview_notes TEXT NULL");
        }
        if (!$pdo->query("SHOW COLUMNS FROM users LIKE 'status'")->fetch()) {
            $pdo->exec("ALTER TABLE users ADD status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved'");
        }
        // upgrade: archive flag for recommendations, resume upload for students
        if (!$pdo->query("SHOW COLUMNS FROM recommendations LIKE 'archived'")->fetch()) {
            $pdo->exec("ALTER TABLE recommendations ADD archived TINYINT(1) NOT NULL DEFAULT 0");
        }
        if (!$pdo->query("SHOW COLUMNS FROM students LIKE 'resume_path'")->fetch()) {
            $pdo->exec("ALTER TABLE students ADD resume_path VARCHAR(255) NULL, ADD resume_name VARCHAR(255) NULL");
        }
        if (!$pdo->query("SHOW COLUMNS FROM users LIKE 'avatar_path'")->fetch()) {
            $pdo->exec("ALTER TABLE users ADD avatar_path VARCHAR(255) NULL");
        }
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings (k VARCHAR(50) PRIMARY KEY, v TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        if ((int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn() === 0) {
            $a = cfg('admin');
            $pdo->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?, 'admin')")
                ->execute([$a['name'], strtolower($a['email']), password_hash($a['password'], PASSWORD_DEFAULT)]);
        }
    } catch (PDOException $ex) {
        exit('<h3>Database connection failed</h3><p>' . e($ex->getMessage()) . '</p><p>Start MySQL in XAMPP and check the settings in <code>config.php</code>.</p>');
    }
    return $pdo;
}

/* ---------- Session / auth ---------- */
if (isset($_SESSION['uid'])) {
    if (time() - ($_SESSION['last'] ?? 0) > cfg('session_minutes') * 60) {
        $_SESSION = [];
        session_destroy();
        session_start();
        flash('err', 'Your session expired. Please log in again.');
        if (basename($_SERVER['SCRIPT_NAME']) !== 'index.php' || dirname($_SERVER['SCRIPT_NAME']) !== base_url()) redirect('index.php');
    } else {
        $_SESSION['last'] = time();
    }
}

function user(): ?array { return isset($_SESSION['uid']) ? $_SESSION : null; }

function login_user(array $u): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['name'] = $u['name'];
    $_SESSION['role'] = $u['role'];
    $_SESSION['must_change'] = (int)$u['must_change'];
    $_SESSION['last'] = time();
}

function require_role(string $role): void
{
    if (!user()) redirect('index.php');
    if ($_SESSION['must_change']) redirect('change_password.php');
    if ($_SESSION['role'] !== $role) redirect(home_for($_SESSION['role']));
}

/* ---------- Helpers ---------- */
function normalize_skills(?string $s): string
{
    $list = array_filter(array_map('trim', explode(',', (string)$s)), 'strlen');
    return implode(', ', array_unique($list));
}
function skills_arr(?string $s): array { return array_values(array_filter(array_map('trim', explode(',', (string)$s)), 'strlen')); }
function temp_password(): string { return substr(strtr(base64_encode(random_bytes(8)), '+/=', 'xyz'), 0, 8); }
function match_score(?string $studentSkills, ?string $requiredSkills): int
{
    $req = skills_arr($requiredSkills);
    if (!$req) return 0;
    $have = array_map('mb_strtolower', skills_arr($studentSkills));
    $hit = count(array_filter($req, fn($r) => in_array(mb_strtolower($r), $have, true)));
    return (int)round($hit / count($req) * 100);
}
function email_exists(string $email): bool
{
    $s = db()->prepare('SELECT 1 FROM users WHERE email=?');
    $s->execute([strtolower($email)]);
    return (bool)$s->fetch();
}
function create_user(string $name, string $email, string $password, string $role, bool $mustChange, string $status = 'approved'): int
{
    $email = strtolower(trim($email));
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new Exception('A valid name and email are required');
    if (strlen($password) < 6) throw new Exception('Password must be at least 6 characters');
    if (email_exists($email)) throw new Exception('Email is already registered');
    db()->prepare('INSERT INTO users(name,email,password,role,must_change,status) VALUES(?,?,?,?,?,?)')
        ->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $role, (int)$mustChange, $status]);
    return (int)db()->lastInsertId();
}
function current_student(): array
{
    $s = db()->prepare('SELECT s.*, u.name, u.email FROM students s JOIN users u ON u.id=s.user_id WHERE s.user_id=?');
    $s->execute([$_SESSION['uid']]);
    return $s->fetch() ?: [];
}
function current_company(): array
{
    $s = db()->prepare('SELECT c.*, u.email FROM companies c JOIN users u ON u.id=c.user_id WHERE c.user_id=?');
    $s->execute([$_SESSION['uid']]);
    return $s->fetch() ?: [];
}
function post(string $k): string { return trim((string)($_POST[$k] ?? '')); }


/* ---------- Dropdown lists (courses / year level) ---------- */
function year_levels(): array { return ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year', '6th Year']; }
function ph_courses(): array
{
    return [
        'Information Technology & Computing' => [
            'BSIT - Bachelor of Science in Information Technology', 'BSCS - Bachelor of Science in Computer Science',
            'BSIS - Bachelor of Science in Information Systems', 'BSEMC - Bachelor of Science in Entertainment and Multimedia Computing',
            'BSDS - Bachelor of Science in Data Science', 'BLIS - Bachelor of Library and Information Science',
            'ACT - Associate in Computer Technology', 'BSCpE - Bachelor of Science in Computer Engineering',
        ],
        'Engineering & Architecture' => [
            'BSCE - Bachelor of Science in Civil Engineering', 'BSEE - Bachelor of Science in Electrical Engineering',
            'BSECE - Bachelor of Science in Electronics Engineering', 'BSME - Bachelor of Science in Mechanical Engineering',
            'BSChE - Bachelor of Science in Chemical Engineering', 'BSIE - Bachelor of Science in Industrial Engineering',
            'BSGE - Bachelor of Science in Geodetic Engineering', 'BSMinE - Bachelor of Science in Mining Engineering',
            'BSMetE - Bachelor of Science in Metallurgical Engineering', 'BSSE - Bachelor of Science in Sanitary Engineering',
            'BSAE - Bachelor of Science in Agricultural and Biosystems Engineering', 'BSAeroE - Bachelor of Science in Aeronautical Engineering',
            'BSNAME - Bachelor of Science in Naval Architecture and Marine Engineering', 'BSPetE - Bachelor of Science in Petroleum Engineering',
            'BSMfgE - Bachelor of Science in Manufacturing Engineering', 'BSArch - Bachelor of Science in Architecture',
            'BSID - Bachelor of Science in Interior Design', 'BSEnvPlan - Bachelor of Science in Environmental Planning',
        ],
        'Business, Accountancy & Management' => [
            'BSBA - Bachelor of Science in Business Administration', 'BSA - Bachelor of Science in Accountancy',
            'BSAT - Bachelor of Science in Accounting Technology', 'BSMA - Bachelor of Science in Management Accounting',
            'BSE - Bachelor of Science in Entrepreneurship', 'BSOA - Bachelor of Science in Office Administration',
            'BSREM - Bachelor of Science in Real Estate Management', 'BSFM - Bachelor of Science in Financial Management',
            'BSMM - Bachelor of Science in Marketing Management', 'BSHRM - Bachelor of Science in Human Resource Management',
            'BSBAM - Bachelor of Science in Business Analytics', 'BSLM - Bachelor of Science in Logistics Management',
            'BSCoop - Bachelor of Science in Cooperatives Management', 'BPA - Bachelor of Public Administration',
        ],
        'Hospitality, Tourism & Travel' => [
            'BSHM - Bachelor of Science in Hospitality Management', 'BSTM - Bachelor of Science in Tourism Management',
            'BSHRM - Bachelor of Science in Hotel and Restaurant Management', 'BSCA - Bachelor of Science in Culinary Arts',
            'BSTrM - Bachelor of Science in Travel Management',
        ],
        'Education' => [
            'BEEd - Bachelor of Elementary Education', 'BSEd - Bachelor of Secondary Education',
            'BECEd - Bachelor of Early Childhood Education', 'BSNEd - Bachelor of Special Needs Education',
            'BPEd - Bachelor of Physical Education', 'BTLEd - Bachelor of Technology and Livelihood Education',
            'BCAEd - Bachelor of Culture and Arts Education', 'BTVTEd - Bachelor of Technical-Vocational Teacher Education',
        ],
        'Health Sciences' => [
            'BSN - Bachelor of Science in Nursing', 'BSMT - Bachelor of Science in Medical Technology',
            'BSPharm - Bachelor of Science in Pharmacy', 'BSPT - Bachelor of Science in Physical Therapy',
            'BSOT - Bachelor of Science in Occupational Therapy', 'BSRT - Bachelor of Science in Radiologic Technology',
            'BSRTT - Bachelor of Science in Respiratory Therapy', 'BSM - Bachelor of Science in Midwifery',
            'BSND - Bachelor of Science in Nutrition and Dietetics', 'BSSLP - Bachelor of Science in Speech-Language Pathology',
            'DMD - Doctor of Dental Medicine', 'BSBio-Med - Bachelor of Science in Biomedical Science',
            'BSPH - Bachelor of Science in Public Health',
            'BSOptom - Doctor of Optometry', 'DVM - Doctor of Veterinary Medicine', 'MD - Doctor of Medicine',
        ],
        'Natural & Applied Sciences, Math' => [
            'BSBio - Bachelor of Science in Biology', 'BSChem - Bachelor of Science in Chemistry',
            'BSPhys - Bachelor of Science in Physics', 'BSMath - Bachelor of Science in Mathematics',
            'BSStat - Bachelor of Science in Statistics', 'BSAppMath - Bachelor of Science in Applied Mathematics',
            'BSAppPhys - Bachelor of Science in Applied Physics', 'BSES - Bachelor of Science in Environmental Science',
            'BSMarBio - Bachelor of Science in Marine Biology', 'BSGeo - Bachelor of Science in Geology',
            'BSFT - Bachelor of Science in Food Technology', 'BSMeteo - Bachelor of Science in Meteorology',
        ],
        'Agriculture, Forestry & Fisheries' => [
            'BSAgri - Bachelor of Science in Agriculture', 'BSAgribiz - Bachelor of Science in Agribusiness',
            'BSFor - Bachelor of Science in Forestry', 'BSFish - Bachelor of Science in Fisheries',
            'BSAgriEd - Bachelor of Science in Agricultural Education', 'BSAnSci - Bachelor of Science in Animal Science',
            'BSAgroforestry - Bachelor of Science in Agroforestry',
        ],
        'Maritime & Aviation' => [
            'BSMT - Bachelor of Science in Marine Transportation', 'BSMarE - Bachelor of Science in Marine Engineering',
            'BSAvTech - Bachelor of Science in Aviation Technology', 'BSAeroT - Bachelor of Science in Aeronautical Technology',
            'BSAM - Bachelor of Science in Aircraft Maintenance Technology', 'BSAvMgt - Bachelor of Science in Air Transportation',
            'BSAvEng - Bachelor of Science in Aviation Electronics Technology',
        ],
        'Arts, Humanities, Communication & Social Sciences' => [
            'AB Comm - Bachelor of Arts in Communication', 'BAJ - Bachelor of Arts in Journalism',
            'BSBC - Bachelor of Science in Broadcasting', 'AB English - Bachelor of Arts in English',
            'AB Literature - Bachelor of Arts in Literature', 'AB Filipino - Bachelor of Arts in Filipino',
            'AB Pol Sci - Bachelor of Arts in Political Science', 'AB History - Bachelor of Arts in History',
            'AB Philosophy - Bachelor of Arts in Philosophy', 'AB Sociology - Bachelor of Arts in Sociology',
            'AB Psych - Bachelor of Arts in Psychology', 'BSPsych - Bachelor of Science in Psychology',
            'BSSW - Bachelor of Science in Social Work', 'BSDevCom - Bachelor of Science in Development Communication',
            'AB IS - Bachelor of Arts in International Studies', 'BSEcon - Bachelor of Science in Economics',
            'AB Econ - Bachelor of Arts in Economics', 'AB Theology - Bachelor of Arts in Theology',
            'BSAnthro - Bachelor of Science in Anthropology', 'BSCrim - Bachelor of Science in Criminology',
            'BSFS - Bachelor of Science in Forensic Science', 'BSPSci - Bachelor of Science in Public Safety',
            'BSCrimSci - Bachelor of Science in Criminal Justice Education', 'BSLaw - Bachelor of Laws / Juris Doctor',
        ],
        'Fine Arts, Design & Media' => [
            'BFA - Bachelor of Fine Arts', 'BFA-ADV - Bachelor of Fine Arts major in Advertising Arts',
            'BFA-Painting - Bachelor of Fine Arts major in Painting', 'BSGD - Bachelor of Science in Graphic Design',
            'BAMMA - Bachelor of Arts in Multimedia Arts', 'BSFashion - Bachelor of Science in Fashion Design',
            'BMusic - Bachelor of Music', 'BPerfArts - Bachelor of Performing Arts', 'BSAnimation - Bachelor of Science in Animation',
            'BAFilm - Bachelor of Arts in Film', 'BSGame - Bachelor of Science in Game Development',
        ],
        'Technology & Technical-Vocational' => [
            'BSIndTech - Bachelor of Science in Industrial Technology', 'BSElecTech - Bachelor of Science in Electrical Technology',
            'BSElxTech - Bachelor of Science in Electronics Technology', 'BSAutoTech - Bachelor of Science in Automotive Technology',
            'BSMechTech - Bachelor of Science in Mechanical Technology', 'BSCivTech - Bachelor of Science in Civil Technology',
            'BSDraftTech - Bachelor of Science in Drafting Technology', 'BSFoodTech - Bachelor of Science in Food Processing Technology',
            'BSGarmentTech - Bachelor of Science in Garment Technology', 'BSMechatronics - Bachelor of Science in Mechatronics',
            'Diploma in Computer Technology', 'Diploma in Electrical Technology',
        ],
        'Senior High School (SHS)' => [
            'SHS - STEM', 'SHS - ABM', 'SHS - HUMSS', 'SHS - GAS', 'SHS - TVL (ICT)', 'SHS - TVL (Home Economics)',
            'SHS - TVL (Industrial Arts)', 'SHS - Arts and Design', 'SHS - Sports',
        ],
    ];
}
/** <select> with optgroups. Keeps an old free-text value selectable so existing data is not lost. */
function select_html(string $name, array $options, ?string $current, string $placeholder, bool $required = false): string
{
    $current = (string)$current;
    $flat = [];
    foreach ($options as $k => $v) { if (is_array($v)) foreach ($v as $o) $flat[] = $o; else $flat[] = $v; }
    $h = '<select name="' . e($name) . '"' . ($required ? ' required' : '') . '><option value="">' . e($placeholder) . '</option>';
    $opt = fn($o) => '<option value="' . e($o) . '"' . (strcasecmp($o, $current) === 0 ? ' selected' : '') . '>' . e($o) . '</option>';
    if ($current !== '' && !in_array(mb_strtolower($current), array_map('mb_strtolower', $flat), true)) $h .= $opt($current);
    foreach ($options as $k => $v) {
        if (is_array($v)) $h .= '<optgroup label="' . e($k) . '">' . implode('', array_map($opt, $v)) . '</optgroup>';
        else $h .= $opt($v);
    }
    return $h . '</select>';
}
function course_select(?string $cur, bool $req = false): string { return select_html('course', ph_courses(), $cur, 'Select course…', $req); }
function year_select(?string $cur, bool $req = false): string { return select_html('year_level', year_levels(), $cur, 'Select year level…', $req); }

/* ---------- Resume upload (stored in storage/resumes, served by resume.php) ---------- */
function resume_dir(): string { $d = __DIR__ . '/../storage/resumes'; if (!is_dir($d)) mkdir($d, 0775, true); return $d; }
function save_resume(int $studentId, array $f): void
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return;
    if ($f['error'] !== UPLOAD_ERR_OK) throw new Exception($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE ? 'Resume is too large (max 5 MB)' : 'Resume upload failed. Please try again.');
    if ($f['size'] > 5 * 1024 * 1024) throw new Exception('Resume is too large (max 5 MB)');
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['pdf', 'doc', 'docx'], true)) throw new Exception('Resume must be a PDF, DOC or DOCX file');
    $stored = 'resume_' . $studentId . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], resume_dir() . '/' . $stored)) throw new Exception('Could not save the resume file. Check that storage/ is writable.');
    $old = db()->prepare('SELECT resume_path FROM students WHERE id=?'); $old->execute([$studentId]);
    if ($p = $old->fetchColumn()) @unlink(resume_dir() . '/' . basename($p));
    db()->prepare('UPDATE students SET resume_path=?, resume_name=? WHERE id=?')->execute([$stored, mb_substr(basename($f['name']), 0, 200), $studentId]);
}
function resume_link(array $s, string $label = 'View resume'): string
{
    if (empty($s['resume_path'])) return '<span class="muted sm">No resume</span>';
    $id = (int)($s['student_pk'] ?? $s['id']);
    return '<a class="btn sm" target="_blank" href="' . e(url('resume.php?sid=' . $id)) . '">📄 ' . e($label) . '</a>';
}

/* ---------- Change password (lives in each role's Profile page) ---------- */
function handle_password_change(): void
{
    $s = db()->prepare('SELECT * FROM users WHERE id=?'); $s->execute([$_SESSION['uid']]); $u = $s->fetch();
    $new = (string)($_POST['new'] ?? '');
    if (!password_verify((string)($_POST['current'] ?? ''), $u['password'])) flash('err', 'Current password is incorrect');
    elseif (strlen($new) < 6) flash('err', 'New password must be at least 6 characters');
    elseif ($new !== ($_POST['confirm'] ?? '')) flash('err', 'Passwords do not match');
    else {
        db()->prepare('UPDATE users SET password=?, must_change=0 WHERE id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $u['id']]);
        $_SESSION['must_change'] = 0;
        flash('ok', 'Password updated');
    }
}
function password_card_html(): string
{
    return '<form class="card" method="post" style="max-width:520px">' . csrf_field() . '<input type="hidden" name="action" value="password">'
        . '<div class="card-head"><h3>Change password</h3></div>'
        . '<label class="field"><span>Current password</span><input type="password" name="current" required autocomplete="current-password"></label>'
        . '<label class="field"><span>New password</span><input type="password" name="new" minlength="6" required autocomplete="new-password"></label>'
        . '<label class="field"><span>Confirm new password</span><input type="password" name="confirm" minlength="6" required autocomplete="new-password"></label>'
        . '<button class="btn primary">Update password</button></form>';
}

/* ---------- Interview schedule (used by company History and Schedule screens) ---------- */
function save_interview_schedule(array $me, string $backTo): never
{
    try {
        $q = db()->prepare("SELECT r.id, u.name, u.email FROM recommendations r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id
            WHERE r.id=? AND r.company_id=? AND r.status='accepted'");
        $q->execute([(int)post('id'), $me['id']]);
        if (!($r = $q->fetch())) throw new Exception('Accepted candidate not found');
        $when = parse_interview(post('interview_at'));
        $place = post('interview_place') ?: (string)$me['address'];
        $notes = post('interview_notes');
        db()->prepare('UPDATE recommendations SET interview_at=?, interview_place=?, interview_notes=? WHERE id=?')->execute([$when, $place, $notes, $r['id']]);
        $sent = send_mail($r['email'], 'Interview schedule updated - ' . $me['company_name'], accepted_email($r['name'], $me['company_name'], (string)$me['address'], $when, $place, $notes, true));
        flash('ok', $sent ? 'Interview schedule saved and the student was emailed.' : 'Interview schedule saved, but the email was NOT sent: ' . last_mail_error());
    } catch (Throwable $ex) { flash('err', $ex->getMessage()); }
    redirect($backTo);
}


/* ---------- Profile pictures / company logos (stored in storage/avatars, served by avatar.php) ---------- */
function avatar_dir(): string { $d = __DIR__ . '/../storage/avatars'; if (!is_dir($d)) mkdir($d, 0775, true); return $d; }
/** <img> for a user's picture; avatar.php draws a coloured initial when there is no picture. $square = company logo style */
function av(int $uid, string $name, int $size = 40, bool $square = false): string
{
    $src = url('avatar.php?uid=' . $uid . '&n=' . rawurlencode(mb_substr(trim($name), 0, 1)));
    return '<img class="av' . ($square ? ' sq' : '') . '" src="' . e($src) . '" alt="' . e($name) . '" width="' . $size . '" height="' . $size . '" style="width:' . $size . 'px;height:' . $size . 'px" loading="lazy">';
}
function save_avatar(int $uid, array $f, bool $remove = false): void
{
    $old = db()->prepare('SELECT avatar_path FROM users WHERE id=?'); $old->execute([$uid]); $oldPath = (string)$old->fetchColumn();
    if ($remove) {
        if ($oldPath) @unlink(avatar_dir() . '/' . basename($oldPath));
        db()->prepare('UPDATE users SET avatar_path=NULL WHERE id=?')->execute([$uid]);
    }
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return;
    if ($f['error'] !== UPLOAD_ERR_OK) throw new Exception($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE ? 'Picture is too large (max 2 MB)' : 'Picture upload failed. Please try again.');
    if ($f['size'] > 2 * 1024 * 1024) throw new Exception('Picture is too large (max 2 MB)');
    $info = @getimagesize($f['tmp_name']);
    $exts = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($exts[$info[2]])) throw new Exception('Picture must be a JPG, PNG, GIF or WEBP image');
    $stored = 'u' . $uid . '_' . bin2hex(random_bytes(6)) . '.' . $exts[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], avatar_dir() . '/' . $stored)) throw new Exception('Could not save the picture. Check that storage/ is writable.');
    if ($oldPath) @unlink(avatar_dir() . '/' . basename($oldPath));
    db()->prepare('UPDATE users SET avatar_path=? WHERE id=?')->execute([$stored, $uid]);
}
/** Upload field for a Profile form. $label: 'Profile picture' or 'Company logo' */
function avatar_field_html(int $uid, string $name, string $label, bool $square): string
{
    $has = (bool)db()->query('SELECT avatar_path FROM users WHERE id=' . (int)$uid)->fetchColumn();
    return '<div class="field full"><span>' . e($label) . ' (JPG, PNG, GIF or WEBP, max 2 MB)</span><div class="av-field">' . av($uid, $name, 84, $square)
        . '<div><input type="file" name="avatar" accept="image/jpeg,image/png,image/gif,image/webp">'
        . ($has ? '<button class="btn sm danger" style="margin-top:8px" name="action" value="remove_avatar" formnovalidate onclick="return confirm(\'Remove your picture?\')">Remove picture</button>' : '')
        . '</div></div></div>';
}
function who_html(int $uid, string $name, string $sub = '', bool $square = false, int $size = 38, string $modal = ''): string
{
    return '<div class="who"' . $modal . '>' . av($uid, $name, $size, $square) . '<div><strong>' . e($name) . '</strong>' . ($sub !== '' ? '<div class="muted sm">' . $sub . '</div>' : '') . '</div></div>';
}


/* ---------- Remove resume ---------- */
function remove_resume(int $studentId): void
{
    $q = db()->prepare('SELECT resume_path FROM students WHERE id=?'); $q->execute([$studentId]);
    if ($p = $q->fetchColumn()) @unlink(resume_dir() . '/' . basename($p));
    db()->prepare('UPDATE students SET resume_path=NULL, resume_name=NULL WHERE id=?')->execute([$studentId]);
}

/* ---------- Info modals (click a student / company card to see everything) ---------- */
function register_modal(string $id, string $html): void { $GLOBALS['__modals'][$id] = $html; }
function modal_attrs(string $id): string { return ' data-modal="' . e($id) . '" tabindex="0" role="button" aria-haspopup="dialog" title="Click to view full information"'; }
function info_item(string $label, string $value, bool $raw = false): string
{
    return '<p><span class="muted sm">' . e($label) . '</span><br>' . ($value === '' ? '-' : ($raw ? $value : e($value))) . '</p>';
}
/** Returns the attributes that make an element open this student's full-information modal. */
function modal_student(int $uid): string
{
    $id = 's' . $uid;
    if (!isset($GLOBALS['__modals'][$id])) {
        $q = db()->prepare('SELECT s.*, s.id AS student_pk, u.name, u.email, u.created_at FROM students s JOIN users u ON u.id=s.user_id WHERE s.user_id=?');
        $q->execute([$uid]);
        if (!($s = $q->fetch())) return '';
        $about = trim((string)$s['about']);
        register_modal($id,
            '<div class="modal-top">' . av($uid, $s['name'], 72) . '<div><h2>' . e($s['name']) . '</h2><div class="muted">' . e($s['course'] ?: 'Student') . ($s['year_level'] ? ' · ' . e($s['year_level']) : '') . '</div></div></div>'
            . '<div class="modal-body"><h4>About</h4>' . ($about !== '' ? '<p>' . nl2br(e($about)) . '</p>' : '<p class="muted">No introduction yet.</p>')
            . '<h4>Skills</h4>' . skills_html($s['skills'])
            . '<h4>Details</h4><div class="modal-info">'
            . info_item('Student ID', (string)$s['student_id']) . info_item('Year level', (string)$s['year_level'])
            . info_item('Course', (string)$s['course']) . info_item('Phone', (string)$s['phone'])
            . info_item('Email', (string)$s['email']) . info_item('Registered', date('M j, Y', strtotime($s['created_at'])))
            . '</div><h4>Resume</h4>' . ($s['resume_path'] ? '<p>' . e($s['resume_name']) . '</p><p style="margin-top:8px">' . resume_link($s) . '</p>' : '<p class="muted">No resume uploaded.</p>') . '</div>');
    }
    return modal_attrs($id);
}
/** Returns the attributes that make an element open this company's full-information modal. */
function modal_company(int $uid): string
{
    $id = 'c' . $uid;
    if (!isset($GLOBALS['__modals'][$id])) {
        $q = db()->prepare('SELECT c.*, u.email, u.created_at FROM companies c JOIN users u ON u.id=c.user_id WHERE c.user_id=?');
        $q->execute([$uid]);
        if (!($c = $q->fetch())) return '';
        register_modal($id, company_modal_inner($c));
    }
    return modal_attrs($id);
}
function company_modal_inner(array $c, string $extraBody = '', string $foot = ''): string
{
    return '<div class="modal-top">' . av((int)$c['user_id'], $c['company_name'], 72, true) . '<div><h2>' . e($c['company_name']) . '</h2><div class="muted">' . e($c['industry'] ?: 'Company') . '</div></div></div>'
        . '<div class="modal-body"><h4>About the company</h4>' . ($c['description'] ? '<p>' . nl2br(e($c['description'])) . '</p>' : '<p class="muted">No description yet.</p>')
        . '<h4>Skills needed</h4>' . skills_html($c['required_skills'])
        . '<h4>Details</h4><div class="modal-info">'
        . info_item('Address', (string)$c['address']) . info_item('Contact number', (string)$c['phone'])
        . info_item('Email', (string)$c['email']) . info_item('Slots available', (string)(int)$c['slots'])
        . (!empty($c['created_at']) ? info_item('Registered', date('M j, Y', strtotime($c['created_at']))) : '')
        . '</div>' . $extraBody . '</div>' . ($foot !== '' ? '<div class="modal-foot">' . $foot . '</div>' : '');
}

/** Cancel button for a student's own application ($r needs id, status, company_id). */
function cancel_form(array $r, string $back = 'requests', bool $small = true): string
{
    $msg = $r['status'] === 'accepted' ? 'This company already accepted you. Cancel this application anyway?' : 'Cancel this application?';
    $label = $r['status'] === 'rejected' ? 'Remove' : 'Cancel application';
    return '<form method="post" class="inline" action="' . e(url('student/requests.php')) . '" onsubmit="return confirm(\'' . e($msg) . '\')">' . csrf_field()
        . '<input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="' . (int)$r['id'] . '"><input type="hidden" name="back" value="' . e($back) . '"><input type="hidden" name="company_id" value="' . (int)$r['company_id'] . '">'
        . '<button class="btn danger' . ($small ? ' sm' : '') . '">' . $label . '</button></form>';
}

/* ---------- UI fragments ---------- */
function skills_html(?string $s): string
{
    $l = skills_arr($s);
    return $l ? '<div class="chips">' . implode('', array_map(fn($x) => '<span class="chip">' . e($x) . '</span>', $l)) . '</div>' : '<span class="muted">-</span>';
}
function score_html(int $n): string
{
    $t = $n >= 70 ? 'high' : ($n >= 40 ? 'mid' : 'low');
    return "<div class=\"score\"><div class=\"bar\"><div class=\"fill $t\" style=\"width:{$n}%\"></div></div><span>{$n}%</span></div>";
}
function interview_html(array $r): string
{
    if (empty($r['interview_at'])) return $r['status'] === 'accepted' ? '<span class="muted">Schedule to be announced</span>' : '<span class="muted">-</span>';
    $out = '<div class="sched"><strong>' . e(date('D, M j, Y', strtotime($r['interview_at']))) . '</strong> at ' . e(date('g:i A', strtotime($r['interview_at'])))
         . '<div class="sm">📍 ' . e($r['interview_place'] ?: 'Place to be announced') . '</div>';
    if (!empty($r['interview_notes'])) $out .= '<div class="muted sm">' . e($r['interview_notes']) . '</div>';
    return $out . '</div>';
}
/** Validates a datetime-local value and returns 'Y-m-d H:i:00' */
function parse_interview(string $v): string
{
    $t = strtotime(str_replace('T', ' ', $v));
    if (!$t) throw new Exception('Please choose the interview date and time');
    return date('Y-m-d H:i:00', $t);
}
function badge_html(string $st): string { return '<span class="badge ' . e($st) . '">' . e($st) . '</span>'; }

/* ---------- Settings & counters ---------- */
function get_setting(string $k, string $default = ''): string
{
    try {
        $q = db()->prepare('SELECT v FROM settings WHERE k=?');
        $q->execute([$k]);
        $v = $q->fetchColumn();
        return $v === false ? $default : (string)$v;
    } catch (Throwable $e) { return $default; }
}
function set_setting(string $k, string $v): void
{
    db()->prepare('INSERT INTO settings(k,v) VALUES(?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)')->execute([$k, $v]);
}
function pending_count(): int { return (int)db()->query("SELECT COUNT(*) FROM users WHERE status='pending'")->fetchColumn(); }
function site_url(string $path = ''): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . url($path);
}

/* ---------- Layout ---------- */
function nav_icon(string $label): string
{
    $p = [
        'Overview' => '<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>',
        'Approvals' => '<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/>',
        'Students' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'Companies' => '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
        'Matching' => '<circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M6 21V9a9 9 0 0 0 9 9"/>',
        'Recommendations' => '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
        'Email settings' => '<path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><polyline points="22,6 12,13 2,6"/>',
        'My requests' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
        'My profile' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'Company profile' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'Candidates' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'Schedule' => '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'History' => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    ];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . ($p[$label] ?? $p['Overview']) . '</svg>';
}

function page_start(string $title, array $tabs = [], string $active = ''): void
{
    $u = user();
    $labels = ['admin' => 'Head Teacher', 'student' => 'Student', 'company' => 'Company'];
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>' . e($title) . ' - InternHub</title><link rel="stylesheet" href="' . e(url('assets/style.css')) . '"></head><body>';
    if ($u) {
        $badge = $u['role'] === 'admin' ? pending_count() : 0;
        echo '<div class="shell"><aside class="sidebar"><div class="side-brand"><span class="logo">IH</span><div><strong>InternHub</strong><small>Internship Portal</small></div></div><nav class="nav">';
        foreach ($tabs as $file => $label) {
            echo '<a href="' . e($file) . '" class="' . ($file === $active ? 'active' : '') . '">' . nav_icon($label) . '<span>' . e($label) . '</span>'
               . ($label === 'Approvals' && $badge ? '<em class="nav-badge">' . $badge . '</em>' : '') . '</a>';
        }
        echo '</nav><div class="side-user">' . av((int)$u['uid'], $u['name'], 38, $u['role'] === 'company')
           . '<div class="side-user-text"><strong>' . e($u['name']) . '</strong><small>' . e($labels[$u['role']] ?? '') . '</small></div>'
           . '<a class="logout" title="Log out" href="' . e(url('logout.php')) . '">' . nav_icon('logout') . '</a></div></aside><main class="main">';
    } else {
        echo '<main class="main">';
    }
    if (!empty($_SESSION['flash'])) {
        [$t, $m] = $_SESSION['flash'];
        unset($_SESSION['flash']);
        echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>';
    }
}
function page_end(): void
{
    echo '</main>' . (user() ? '</div>' : '');
    foreach ($GLOBALS['__modals'] ?? [] as $id => $html) echo '<template id="' . e($id) . '">' . $html . '</template>';
    echo (user() ? '<script src="' . e(url('assets/modal.js')) . '"></script>' : '') . '</body></html>';
}

function admin_tabs(): array { return ['index.php' => 'Overview', 'approvals.php' => 'Approvals', 'students.php' => 'Students', 'companies.php' => 'Companies', 'matching.php' => 'Matching', 'recommendations.php' => 'Recommendations', 'settings.php' => 'Email settings', 'profile.php' => 'My profile']; }
function student_tabs(): array { return ['index.php' => 'Companies', 'requests.php' => 'My requests', 'schedule.php' => 'Schedule', 'profile.php' => 'My profile']; }
function company_tabs(): array { return ['index.php' => 'Candidates', 'schedule.php' => 'Schedule', 'history.php' => 'History', 'profile.php' => 'Company profile']; }
