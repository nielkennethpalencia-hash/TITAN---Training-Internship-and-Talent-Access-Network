<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('company');
$pdo = db();
$me = current_company();

if ($_SERVER['REQUEST_METHOD'] === 'POST') { csrf_check(); save_interview_schedule($me, 'company/history.php'); }

$q = $pdo->prepare("SELECT r.*, u.name, u.email, s.course, s.resume_path, s.user_id AS suid, s.id AS student_pk FROM recommendations r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id
    WHERE r.company_id=? AND r.status<>'pending' ORDER BY r.decided_at DESC");
$q->execute([$me['id']]);
$rows = $q->fetchAll();
page_start('History', company_tabs(), 'history.php');
?>
<div class="page-head"><div><h1>History</h1><p class="muted">Candidates you already responded to, and their interview schedules</p></div></div>
<div class="card">
<?php if (!$rows): ?><div class="empty">No decisions yet.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Student</th><th>Match</th><th>Decision</th><th>Interview schedule</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
<tr<?= modal_student((int)$r['suid']) ?>><td><?= who_html((int)$r['suid'], $r['name'], e($r['email']) . ' · ' . e($r['course'])) ?><div style="margin-top:6px"><?= resume_link($r) ?></div></td>
<td><?= score_html($r['match_score']) ?></td>
<td><?= badge_html($r['status']) ?><div class="muted sm"><?= $r['decided_at'] ? e(date('M j, Y', strtotime($r['decided_at']))) : '' ?></div></td>
<td><?= interview_html($r) ?>
<?php if ($r['status'] === 'accepted'): ?>
  <details class="resched"><summary><?= $r['interview_at'] ? 'Reschedule' : 'Set schedule' ?></summary>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
      <label class="field"><span>Date &amp; time</span><input type="datetime-local" name="interview_at" required value="<?= $r['interview_at'] ? e(date('Y-m-d\TH:i', strtotime($r['interview_at']))) : '' ?>"></label>
      <label class="field"><span>Place</span><input name="interview_place" value="<?= e($r['interview_place']) ?>"></label>
      <label class="field"><span>Notes</span><input name="interview_notes" value="<?= e($r['interview_notes']) ?>"></label>
      <button class="btn primary sm">Save &amp; email student</button></form></details>
<?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></div>
<?php page_end();
