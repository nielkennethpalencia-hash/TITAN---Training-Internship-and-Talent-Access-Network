<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('company');
$me = current_company();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'password') { handle_password_change(); redirect('company/profile.php'); }
    if (post('action') === 'remove_avatar') { try { save_avatar((int)$_SESSION['uid'], [], true); flash('ok', 'Logo removed'); } catch (Throwable $ex) { flash('err', $ex->getMessage()); } redirect('company/profile.php'); }
    if (post('company_name') === '') { flash('err', 'Company name is required'); redirect('company/profile.php'); }
    try {
        db()->prepare('UPDATE companies SET company_name=?, industry=?, address=?, phone=?, description=?, required_skills=?, slots=? WHERE id=?')
            ->execute([post('company_name'), post('industry'), post('address'), post('phone'), post('description'), normalize_skills(post('required_skills')), max(0, (int)post('slots')), $me['id']]);
        db()->prepare('UPDATE users SET name=? WHERE id=?')->execute([post('company_name'), $_SESSION['uid']]);
        $_SESSION['name'] = post('company_name');
        save_avatar((int)$_SESSION['uid'], $_FILES['avatar'] ?? []);
    flash('ok', 'Company profile saved');
    } catch (Throwable $ex) { flash('err', $ex->getMessage()); }
    redirect('company/profile.php');
}
page_start('Company profile', company_tabs(), 'profile.php');
?>
<div class="page-head"><div><h1>Company profile</h1><p class="muted">Required skills are used to rank students and calculate match scores</p></div></div>
<form class="card" method="post" enctype="multipart/form-data"><?= csrf_field() ?>
  <div class="grid2">
    <?= avatar_field_html((int)$_SESSION['uid'], $me['company_name'], 'Company logo', true) ?>
    <label class="field"><span>Company name</span><input name="company_name" required value="<?= e($me['company_name']) ?>"></label>
    <label class="field"><span>Email</span><input value="<?= e($me['email']) ?>" disabled></label>
    <label class="field"><span>Industry</span><input name="industry" value="<?= e($me['industry']) ?>"></label>
    <label class="field"><span>Phone</span><input name="phone" value="<?= e($me['phone']) ?>"></label>
    <label class="field full"><span>Address</span><input name="address" value="<?= e($me['address']) ?>"></label>
    <label class="field"><span>Slots available</span><input type="number" min="0" name="slots" value="<?= (int)$me['slots'] ?>"></label>
    <label class="field full"><span>Skills you need (comma separated)</span><input name="required_skills" value="<?= e($me['required_skills']) ?>"></label>
    <label class="field full"><span>About the company</span><textarea name="description" rows="3"><?= e($me['description']) ?></textarea></label>
  </div>
  <button class="btn primary">Save profile</button>
</form>
<?= password_card_html() ?>
<?php page_end();
