<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('company');
$pdo = db();
$me = current_company();
if ($_SERVER['REQUEST_METHOD'] === 'POST') { csrf_check(); save_interview_schedule($me, 'company/schedule.php'); }

$q = $pdo->prepare("SELECT r.*, u.name, u.email, s.course, s.phone AS student_phone, s.resume_path, s.user_id AS suid, s.id AS student_pk
    FROM recommendations r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id
    WHERE r.company_id=? AND r.status='accepted' ORDER BY r.interview_at ASC");
$q->execute([$me['id']]);
$upcoming = $past = $tba = [];
foreach ($q->fetchAll() as $r) {
    if (!$r['interview_at']) $tba[] = $r;
    elseif (strtotime($r['interview_at']) >= time()) $upcoming[] = $r;
    else $past[] = $r;
}
$past = array_reverse($past);
$list = function (array $rows, string $empty) {
    if (!$rows) { echo '<div class="empty">' . e($empty) . '</div>'; return; }
    echo '<div class="table-wrap"><table><thead><tr><th>Student</th><th>Interview</th><th></th></tr></thead><tbody>';
    foreach ($rows as $r) {
        echo '<tr' . modal_student((int)$r['suid']) . '><td>' . who_html((int)$r['suid'], $r['name'], e($r['email']) . ' · ' . e($r['course'])) . '<div style="margin-top:6px">' . resume_link($r) . '</div></td><td>' . interview_html($r) . '</td><td>';
        echo '<details class="resched"><summary>' . ($r['interview_at'] ? 'Reschedule' : 'Set schedule') . '</summary><form method="post">' . csrf_field() . '<input type="hidden" name="id" value="' . (int)$r['id'] . '">'
           . '<label class="field"><span>Date &amp; time</span><input type="datetime-local" name="interview_at" required value="' . ($r['interview_at'] ? e(date('Y-m-d\TH:i', strtotime($r['interview_at']))) : '') . '"></label>'
           . '<label class="field"><span>Place</span><input name="interview_place" value="' . e($r['interview_place']) . '"></label>'
           . '<label class="field"><span>Notes</span><input name="interview_notes" value="' . e($r['interview_notes']) . '"></label>'
           . '<button class="btn primary sm">Save &amp; email student</button></form></details></td></tr>';
    }
    echo '</tbody></table></div>';
};
page_start('Schedule', company_tabs(), 'schedule.php');
?>
<div class="page-head"><div><h1>Interview schedule</h1><p class="muted">Face-to-face interviews with the students you accepted</p></div></div>
<div class="stats three">
  <div class="stat green"><div class="num"><?= count($upcoming) ?></div><div class="lbl">Upcoming</div></div>
  <div class="stat amber"><div class="num"><?= count($tba) ?></div><div class="lbl">Not scheduled yet</div></div>
  <div class="stat"><div class="num"><?= count($past) ?></div><div class="lbl">Done / past</div></div>
</div>
<div class="card"><div class="card-head"><h3>Upcoming interviews</h3></div><?php $list($upcoming, 'No upcoming interviews.'); ?></div>
<?php if ($tba): ?><div class="card"><div class="card-head"><h3>Needs a schedule</h3></div><?php $list($tba, ''); ?></div><?php endif; ?>
<?php if ($past): ?><div class="card"><div class="card-head"><h3>Past interviews</h3></div><?php $list($past, ''); ?></div><?php endif; ?>
<?php page_end();
