<?php
require __DIR__ . '/../includes/bootstrap.php';
require_role('company');
$pdo = db();
$me = current_company();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $status = post('status');
    if (in_array($status, ['accepted', 'rejected'], true)) {
        $q = $pdo->prepare("SELECT r.id, u.name, u.email FROM recommendations r JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id
            WHERE r.id=? AND r.company_id=? AND r.status='pending'");
        $q->execute([(int)post('id'), $me['id']]);
        if ($r = $q->fetch()) {
            if ($status === 'accepted') {
                try {
                    $when = parse_interview(post('interview_at'));
                    $place = post('interview_place') ?: (string)$me['address'];
                    $notes = post('interview_notes');
                    $pdo->prepare('UPDATE recommendations SET status=?, decided_at=NOW(), interview_at=?, interview_place=?, interview_notes=? WHERE id=?')
                        ->execute([$status, $when, $place, $notes, $r['id']]);
                    $sent = send_mail($r['email'], "You've been accepted by " . $me['company_name'], accepted_email($r['name'], $me['company_name'], (string)$me['address'], $when, $place, $notes));
                    flash('ok', $sent ? "Accepted. {$r['name']} was notified by email with the interview schedule." : 'Accepted and interview scheduled, but the email was NOT sent: ' . last_mail_error() . ' Ask the head teacher to check Email settings.');
                } catch (Throwable $ex) { flash('err', $ex->getMessage()); }
            } else {
                $pdo->prepare('UPDATE recommendations SET status=?, decided_at=NOW() WHERE id=?')->execute([$status, $r['id']]);
                flash('ok', 'Candidate rejected');
            }
        } else flash('err', 'Recommendation not found or already answered');
    }
    redirect('company/index.php');
}

$q = $pdo->prepare("SELECT r.*, u.name, u.email, s.course, s.year_level, s.skills, s.about, s.user_id AS suid, s.resume_path, s.id AS student_pk FROM recommendations r
    JOIN students s ON s.id=r.student_id JOIN users u ON u.id=s.user_id WHERE r.company_id=? AND r.status='pending' AND r.archived=0 ORDER BY r.match_score DESC, r.created_at");
$q->execute([$me['id']]);
$pending = $q->fetchAll();
$cnt = $pdo->prepare('SELECT status, COUNT(*) n FROM recommendations WHERE company_id=? GROUP BY status');
$cnt->execute([$me['id']]);
$counts = array_column($cnt->fetchAll(), 'n', 'status');

page_start('Candidates', company_tabs(), 'index.php');
?>
<div class="page-head"><div class="who"><?= av((int)$_SESSION['uid'], $me['company_name'], 56, true) ?><div><h1><?= e($me['company_name']) ?></h1><p class="muted">Review recommended students and respond</p></div></div></div>
<div class="stats three">
  <div class="stat amber"><div class="num"><?= (int)($counts['pending'] ?? 0) ?></div><div class="lbl">Awaiting your response</div></div>
  <div class="stat green"><div class="num"><?= (int)($counts['accepted'] ?? 0) ?></div><div class="lbl">Accepted</div></div>
  <div class="stat red"><div class="num"><?= (int)($counts['rejected'] ?? 0) ?></div><div class="lbl">Rejected</div></div>
</div>
<div class="cards">
<?php if (!$pending): ?><div class="empty">No candidates waiting for your response.</div><?php endif; ?>
<?php foreach ($pending as $r): ?>
  <div class="card"<?= modal_student((int)$r['suid']) ?>>
    <div class="card-head"><div class="who"><?= av((int)$r['suid'], $r['name'], 52) ?><div><h3><?= e($r['name']) ?></h3><div class="muted sm"><?= e($r['course']) ?><?= $r['year_level'] ? ' · ' . e($r['year_level']) : '' ?></div></div></div><?= score_html($r['match_score']) ?></div>
    <div class="muted sm">Skills</div><?= skills_html($r['skills']) ?>
    <?php if ($r['about']): ?><p class="sm"><?= e($r['about']) ?></p><?php endif; ?>
    <div style="margin:8px 0"><?= resume_link($r) ?></div>
    <div class="muted sm">Recommended by <?= $r['recommended_by'] === 'admin' ? 'the head teacher' : 'the student' ?> · <?= e($r['email']) ?></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
      <div class="interview-box"><div class="sm"><strong>Face-to-face interview (needed to accept)</strong></div>
        <div class="grid2">
          <label class="field"><span>Date &amp; time</span><input type="datetime-local" name="interview_at" min="<?= date('Y-m-d\TH:i') ?>" required></label>
          <label class="field"><span>Place</span><input name="interview_place" placeholder="<?= e($me['address'] ?: 'Office address') ?>"></label>
          <label class="field full"><span>Notes for the student (optional)</span><input name="interview_notes" placeholder="Bring resume and valid ID"></label>
        </div></div>
      <div class="card-foot">
        <button class="btn danger" name="status" value="rejected" formnovalidate onclick="return confirm('Reject this candidate?')">Reject</button>
        <button class="btn primary" name="status" value="accepted">Accept &amp; schedule interview</button></div></form>
  </div>
<?php endforeach; ?>
</div>
<?php page_end();
