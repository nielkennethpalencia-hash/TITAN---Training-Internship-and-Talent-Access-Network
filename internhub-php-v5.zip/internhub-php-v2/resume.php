<?php
// Serves a student's resume to: the student, the admin, or a company that has a request with that student.
require __DIR__ . '/includes/bootstrap.php';
if (!user() || $_SESSION['must_change']) redirect('index.php');
$sid = (int)($_GET['sid'] ?? 0);
$q = db()->prepare('SELECT s.user_id, s.resume_path, s.resume_name FROM students s WHERE s.id=?');
$q->execute([$sid]);
$s = $q->fetch();
$ok = false;
if ($s && $s['resume_path']) {
    $role = $_SESSION['role'];
    if ($role === 'admin') $ok = true;
    elseif ($role === 'student') $ok = (int)$s['user_id'] === (int)$_SESSION['uid'];
    elseif ($role === 'company') {
        $c = db()->prepare('SELECT 1 FROM recommendations r JOIN companies c ON c.id=r.company_id WHERE r.student_id=? AND c.user_id=?');
        $c->execute([$sid, $_SESSION['uid']]);
        $ok = (bool)$c->fetch();
    }
}
$file = $ok ? resume_dir() . '/' . basename($s['resume_path']) : '';
if (!$ok || !is_file($file)) { http_response_code(404); exit('Resume not found.'); }
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$types = ['pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
header('Content-Disposition: ' . ($ext === 'pdf' ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', $s['resume_name'] ?: basename($file)) . '"');
header('Content-Length: ' . filesize($file));
header('X-Content-Type-Options: nosniff');
readfile($file);
