-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2026 at 03:26 PM
-- Server version: 10.11.19-MariaDB
-- PHP Version: 8.5.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internhub`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `industry` varchar(120) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `required_skills` text DEFAULT NULL,
  `slots` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `user_id`, `company_name`, `industry`, `address`, `phone`, `description`, `required_skills`, `slots`) VALUES
(1, 3, 'INFOTECH COMP.', 'technology', 'lingsat san fernando la union', '09387577719', '', 'PHP', 3),
(2, 5, 'HIGH-TECH COMP', 'technology', 'bacnotan la union', '0913121231', NULL, 'PHP', 3),
(3, 6, 'ktech comp', 'technology', 'san fer', '0909876655', NULL, 'PHP', 4),
(4, 10, 'MOB APP', 'TECHNOLOGY', 'SFC', '09524420033', NULL, 'PHP', 1);

-- --------------------------------------------------------

--
-- Table structure for table `recommendations`
--

CREATE TABLE `recommendations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `recommended_by` enum('admin','student') NOT NULL,
  `match_score` int(11) NOT NULL DEFAULT 0,
  `status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `decided_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `interview_at` datetime DEFAULT NULL,
  `interview_place` varchar(255) DEFAULT NULL,
  `interview_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recommendations`
--

INSERT INTO `recommendations` (`id`, `student_id`, `company_id`, `recommended_by`, `match_score`, `status`, `decided_at`, `created_at`, `interview_at`, `interview_place`, `interview_notes`) VALUES
(1, 1, 1, 'student', 100, 'accepted', '2026-11-23 18:54:13', '2026-11-23 10:53:49', NULL, NULL, NULL),
(2, 2, 1, 'student', 100, 'accepted', '2026-11-23 18:59:27', '2026-11-23 10:59:12', NULL, NULL, NULL),
(3, 1, 2, 'student', 100, 'accepted', '2026-11-23 19:09:26', '2026-11-23 11:08:29', '2026-11-26 19:09:00', 'bacnotan', 'bring resume and valid id'),
(4, 1, 3, 'student', 100, 'accepted', '2026-11-23 19:13:46', '2026-11-23 11:13:01', '2026-11-27 19:13:00', 'sfc', 'bring resume and valid id'),
(5, 2, 3, 'admin', 100, 'accepted', '2026-11-23 19:17:03', '2026-11-23 11:16:26', '2026-11-28 19:16:00', 'sfc', 'bring resume and valid id');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `k` varchar(50) NOT NULL,
  `v` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `course` varchar(120) DEFAULT NULL,
  `year_level` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `about` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_id`, `course`, `year_level`, `phone`, `skills`, `about`) VALUES
(1, 2, '23101042', 'BSIT', '3rd year', '', 'PHP', NULL),
(2, 4, '23101043', 'BSIT', '3rd year', '', 'PHP', NULL),
(3, 7, '24101042', 'BSIT', '3rd year', '', 'php', NULL),
(4, 8, '24123123', 'BSIT', '3rd year', '', 'PHP', NULL),
(5, 9, '24100606', 'BSIT', '3rd year', '09524420033', 'PHP', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student','company') NOT NULL,
  `must_change` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'approved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `must_change`, `created_at`, `status`) VALUES
(1, 'Head Teacher', 'admin@school.edu', '$2y$10$DOYekqTwAhnFMA7rx0yqku/kPHOdkoDkDkXfSzQkeGNvHzs6A8.zW', 'admin', 0, '2026-11-23 10:48:58', 'approved'),
(2, 'kurt russel cabagbag', 'cabagbagkurt2@gmail.com', '$2y$10$R6kZKOSeve1FmVO/mzAR5.3H3CK5PdONKc1P35SSCun97ooM3UFsu', 'student', 0, '2026-11-23 10:48:58', 'approved'),
(3, 'INFOTECH COMP.', 'infotech@gmail.com', '$2y$10$tZc70qqxPl5LUh6yjne/M.d9BFU/3Lq5S9qcQPLKXEv/Tvq1LcBTG', 'company', 0, '2026-11-23 10:53:25', 'approved'),
(4, 'kurty cabagbag', 'russelkurt366@gmail.com', '$2y$10$7OdkDDccBQQ88omZRlUpz.zXIyMt.fbbBejgwfSoSaz2Pf3wy2/HC', 'student', 0, '2026-11-23 10:58:52', 'approved'),
(5, 'HIGH-TECH COMP', 'hightech@gmail.com', '$2y$10$O.SrkxUZYw/mRs5aeNmUgOmeMgeiFRdXgtZy1wU75NLdwXqJP4QX6', 'company', 0, '2026-11-23 11:08:14', 'approved'),
(6, 'ktech comp', 'ktech@gmail.com', '$2y$10$neD6yKsoAjzxZxqxKrysnOTPwwu2.bYEC7ZF4g3/AX9xyS1mzg1Ei', 'company', 0, '2026-11-23 11:12:38', 'approved'),
(7, 'PALENCIA KENNETH', 'palencia@gmail.com', '$2y$10$POENYcTwKN22vJEl9bhBx.k6qNiAsKST.rfV2H1PjLx1Fgete/N2u', 'student', 0, '2026-11-23 12:46:15', 'approved'),
(8, 'Sagabaen Jayvie', 'sagabaen@gmail.com', '$2y$10$/VA9iklbKaIc9n0imIS4NOewzEZ6HsIf.nnTAjyu2sWo7nolBzfmy', 'student', 0, '2026-11-23 12:57:27', 'pending'),
(9, 'kanot panot', '24100606@slc-sflu.edu.ph', '$2y$12$Kle0/e1wKE9qa/sKHqeja.Sm9nvyhLWiM8043hWtBJd4/No3guZCK', 'student', 0, '2026-11-23 13:22:44', 'approved'),
(10, 'MOB APP', 'mobapp@gmail.com', '$2y$12$8b6C95R2x6EeY9BpF56l/eNGFxbrqFvjI1BqvIl0PIRuJDptPd11O', 'company', 0, '2026-11-23 13:30:45', 'approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_pair` (`student_id`,`company_id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`k`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `recommendations`
--
ALTER TABLE `recommendations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `recommendations`
--
ALTER TABLE `recommendations`
  ADD CONSTRAINT `recommendations_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `recommendations_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
